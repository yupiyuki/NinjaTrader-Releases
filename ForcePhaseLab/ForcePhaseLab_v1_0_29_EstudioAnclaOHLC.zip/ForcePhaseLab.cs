﻿#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using System.Xml.Serialization;
using System.Xml;
using System.Reflection;
using WpfInput = System.Windows.Input;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NativeDraw = NinjaTrader.NinjaScript.DrawingTools.Draw;
using System.Globalization;
using System.IO;
using System.Text;
using System.Security.Cryptography;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators;
using SharpDX;
using SharpDX.Direct2D1;
using SharpDX.DirectWrite;
using DXBrush = SharpDX.Direct2D1.Brush;
using DXColor = SharpDX.Color4;
using WpfBrush = System.Windows.Media.Brush;
using WpfBrushes = System.Windows.Media.Brushes;
#endregion

// ForcePhaseLab v1.0.29 · Estudio de ancla directo sobre OHLC historico cargado en NinjaTrader.
// Indicador ORIGINAL de experimentacion. NO deriva del codigo propietario de TachEon FORCE.
// Anclas A y B desplazables; reticulas A/B; filtrado independiente de tendencia/contratendencia.
namespace NinjaTrader.NinjaScript.Indicators
{
    public enum PhaseTestAverageType { HMA, WMA, EMA, SMA }
    public enum PhaseTestTrendFilterMode { PosicionMA, PendienteMA, Combinado }
    public enum PhaseTestPanelPlacement { ArribaIzquierda, ArribaCentro, ArribaDerecha, AbajoIzquierda, AbajoCentro, AbajoDerecha }

    public class ForcePhaseLab : Indicator
    {
        private Indicator activeAverage;
        private ATR slopeAtr;
        private readonly List<int> slopeStateCache = new List<int>();
        private int cachedSlopeLookback = -1, cachedSlopeAtrPeriod = -1;
        private double cachedSlopeThreshold = double.NaN;
        // Cache ATR de Wilder por barra cerrada. Permite cambiar el periodo desde el panel
        // sin instanciar indicadores después de DataLoaded ni consultar datos futuros.
        private readonly List<double> markerAtrCache = new List<double>();
        private int cachedMarkerAtrPeriod = -1;
        private int anchorIndexA = -1;
        private int anchorIndexB = -1;
        private bool anchorsInitialized;
        private Grid toolbar;
        private CheckBox chkA, chkB, chkWith, chkAgainst, chkPercentBands;
        private TextBlock toolbarLabel, templateStatusLabel, anchorStudyStatusLabel;
        private Button anchorStudyApplyButton;
        private bool anchorStudyRunning;
        private AnchorStudyResult anchorStudyResult;

        // El estudio evalua una reticula fija 1/2 por sus giros locales historicos.
        // Selecciona SOLO con el primer 70% de las barras y audita en el 30% final.
        // No modifica la reticula existente hasta pulsar Aplicar estudio.
        private sealed class AnchorStudyResult
        {
            public int Interval, Phase, Bars, SampleFirst, SampleSecond, SampleValidation;
            public double TrainQuality, ValidationQuality, TrainBaseline, ValidationBaseline;
            public DateTime LastBarTime;
        }
        private ComboBox offsetModeSelector;
        private bool syncingTemplatePanel;
        private volatile bool templateLoading;
        private static readonly string[] TemplateFields = new string[] {
            "AnchorProfile", "SeparationBars", "StudyMinBars", "StudyMaxBars", "BaseBinary", "AnchorAIndex", "AnchorBIndex",
            "AnchorStartStamp", "AnchorEndStamp", "AnchorStartPrice", "AnchorEndPrice",
            "ShowA", "ShowB", "ShowWithTrend", "ShowAgainstTrend", "AverageType", "AveragePeriod",
            "ShowAverage", "TrendToleranceTicks", "TrendFilterMode", "SlopeLookback", "SlopeThresholdAtr",
            "SlopeAtrPeriod", "AverageLineWidth", "SlopeUpBrushSerialize", "SlopeDownBrushSerialize", "SlopeFlatBrushSerialize",
            "FutureSignals", "HistorySignals", "ShowToolbar", "PanelPlacement", "PanelTextSize",
            "MarkerOffsetTicks", "UseAtrMarkerOffset", "MarkerOffsetAtrMultiple", "MarkerAtrPeriod",
            "SignalVerticalWidth", "SignalVerticalStyle", "SignalHorizontalWidth", "SignalHorizontalStyle",
            "SignalDotSize", "SignalLabelFontSize", "MutedVerticalWidth", "MutedHorizontalWidth", "MutedDotSize",
            "SignalBuyBrushSerialize", "SignalSellBrushSerialize", "SignalMutedBrushSerialize",
            "HighlightAnchorCycle", "AnchorCycleOpacity", "AnchorCycleBrushSerialize",
            "ShowPercentBands", "PercentBaseRange", "PercentTestLevel", "PercentZoneUpperLevel",
            "PercentBandWidth", "PercentBandStyle", "PercentBandBrushSerialize",
            "PercentZoneBrushSerialize", "PercentZoneOpacity"
        };
        private TextBox offsetEditor, toleranceEditor, atrPeriodEditor, percentBaseEditor, percentLevelEditor, percentUpperEditor;
        private Action commitPercentEditors, restorePercentEditors;
        private Action commitAtrPeriodEditor, restoreAtrPeriodEditor;
        private Action commitToleranceEditor, restoreToleranceEditor;
        // Cache cronologica de tendencia; solo la consume el renderizador.
        private readonly List<int> trendStateCache = new List<int>();
        private int cachedToleranceTicks = -1;
        private Action commitOffsetEditor, restoreOffsetEditor;
        private WpfInput.InputManager offsetInputManager;
        // Una sola geometria editable: A0 y A1. La reticula B es su copia +1 barra.
        private NinjaTrader.NinjaScript.DrawingTools.Line nativeAnchor;
        private volatile bool nativeAnchorPending;
        // Al mover el cuerpo, conservar la distancia en barras, no en minutos.
        private bool movingWholeAnchor;
        private int wholeAnchorSpan;
        private const string NativeAnchorTag = "ForcePhaseLab_EditableAnchor";
        private double anchorPriceA = double.NaN, anchorPriceB = double.NaN;
        private volatile int lastClosedIndex = -1;
        private int futureCacheBase = -1;
        private DateTime futureCacheBaseTime = DateTime.MinValue;
        private readonly List<DateTime> futureTimes = new List<DateTime>();
        private TimeZoneInfo applicationTimeZone;
        private double nominalSeconds;
        private readonly object anchorGate = new object();
        private static readonly object anchorFileGate = new object();
        private string anchorStatePath;
        private bool anchorRestoreAttempted, anchorFileInvalid, anchorDirty;
        private bool nativeDragActive;
        private string anchorStatus = string.Empty;

        // Una instancia por instrumento/periodo/sesion/perfil comparte persistencia.
        // Cambiar perfil para usar varias reticulas independientes en el mismo mercado.
        [Display(Name = "Perfil de ancla", GroupName = "01. Geometria", Order = 6)]
        public string AnchorProfile { get; set; }

        [NinjaScriptProperty]
        [Range(2, 300)]
        [Display(Name = "Barras entre anclas", GroupName = "01. Geometria", Order = 1)]
        public int SeparationBars { get; set; }

        [NinjaScriptProperty]
        [Range(2, 300)]
        [Display(Name = "Estudio · mínimo barras", Description = "Menor intervalo a estudiar en OHLC (no mueve el ancla).", GroupName = "01. Geometria", Order = 7)]
        public int StudyMinBars { get; set; }

        [NinjaScriptProperty]
        [Range(2, 300)]
        [Display(Name = "Estudio · máximo barras", Description = "Mayor intervalo a estudiar; 60 por defecto para evitar ajustes demasiado dispersos.", GroupName = "01. Geometria", Order = 8)]
        public int StudyMaxBars { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Binaria inicial A", Description = "1 alcista / 2 bajista", GroupName = "01. Geometria", Order = 3)]
        [Range(1, 2)]
        public int BaseBinary { get; set; }

        [NinjaScriptProperty]
        [Range(-1, int.MaxValue)]
        [Display(Name = "Ancla A indice (−1 = automatica)", GroupName = "01. Geometria", Order = 4)]
        public int AnchorAIndex { get; set; }

        [NinjaScriptProperty]
        [Range(-1, int.MaxValue)]
        [Display(Name = "Ancla B indice (−1 = A + barras)", GroupName = "01. Geometria", Order = 5)]
        public int AnchorBIndex { get; set; }

        // Guardar tiempo absoluto, no solamente indice relativo al historico cargado.
        [Browsable(false)]
        public string AnchorStartStamp { get; set; }
        [Browsable(false)]
        public string AnchorEndStamp { get; set; }
        [Browsable(false)]
        public double AnchorStartPrice { get; set; }
        [Browsable(false)]
        public double AnchorEndPrice { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Reticula A B0", GroupName = "02. Reticulas", Order = 1)]
        public bool ShowA { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Reticula B B+1 invertida", GroupName = "02. Reticulas", Order = 2)]
        public bool ShowB { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Mostrar a favor de tendencia", GroupName = "03. Filtro", Order = 1)]
        public bool ShowWithTrend { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Mostrar contra tendencia", GroupName = "03. Filtro", Order = 2)]
        public bool ShowAgainstTrend { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Tipo de media", GroupName = "03. Filtro", Order = 3)]
        public PhaseTestAverageType AverageType { get; set; }

        [NinjaScriptProperty]
        [Range(2, 500)]
        [Display(Name = "Periodo de media", GroupName = "03. Filtro", Order = 4)]
        public int AveragePeriod { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Mostrar media", GroupName = "03. Filtro", Order = 5)]
        public bool ShowAverage { get; set; }

        [Range(0, 2000)]
        [Display(Name = "Holgura MA (ticks)", Description = "Mantiene la tendencia anterior dentro de la banda de la media. Cero = filtro estricto.", GroupName = "03. Filtro", Order = 6)]
        public int TrendToleranceTicks { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Criterio de tendencia", Description = "Posición respecto a la media, pendiente de la media o coincidencia de ambas.", GroupName = "03. Filtro", Order = 7)]
        public PhaseTestTrendFilterMode TrendFilterMode { get; set; }

        [NinjaScriptProperty]
        [Range(1, 12)]
        [Display(Name = "Pendiente · velas", Description = "Comparación de la media con N barras anteriores, sin confirmar con velas posteriores.", GroupName = "03. Filtro", Order = 8)]
        public int SlopeLookback { get; set; }

        [NinjaScriptProperty]
        [Range(0.0, 2.0)]
        [Display(Name = "Pendiente · umbral ATR/barra", Description = "Inclinación mínima por vela dividida por ATR. Histéresis interna de 60 %.", GroupName = "03. Filtro", Order = 9)]
        public double SlopeThresholdAtr { get; set; }

        [NinjaScriptProperty]
        [Range(1, 500)]
        [Display(Name = "Pendiente · periodo ATR", Description = "ATR solo para normalizar la pendiente (independiente del offset de los puntos).", GroupName = "03. Filtro", Order = 10)]
        public int SlopeAtrPeriod { get; set; }

        [NinjaScriptProperty]
        [Range(1, 12)]
        [Display(Name = "Grosor de la media", Description = "Grosor de la línea de la media filtrada y coloreada por pendiente.", GroupName = "03. Filtro", Order = 14)]
        public int AverageLineWidth { get; set; }

        [XmlIgnore]
        [Display(Name = "Media · color ascendente", GroupName = "03. Filtro", Order = 11)]
        public WpfBrush SlopeUpBrush { get; set; }
        [Browsable(false)]
        public string SlopeUpBrushSerialize
        {
            get { return Serialize.BrushToString(SlopeUpBrush); }
            set { SlopeUpBrush = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Media · color descendente", GroupName = "03. Filtro", Order = 12)]
        public WpfBrush SlopeDownBrush { get; set; }
        [Browsable(false)]
        public string SlopeDownBrushSerialize
        {
            get { return Serialize.BrushToString(SlopeDownBrush); }
            set { SlopeDownBrush = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Media · color lateral", GroupName = "03. Filtro", Order = 13)]
        public WpfBrush SlopeFlatBrush { get; set; }
        [Browsable(false)]
        public string SlopeFlatBrushSerialize
        {
            get { return Serialize.BrushToString(SlopeFlatBrush); }
            set { SlopeFlatBrush = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [Range(0, 40)]
        [Display(Name = "Señales futuras", GroupName = "04. Visual", Order = 1)]
        public int FutureSignals { get; set; }

        [NinjaScriptProperty]
        [Range(5, 300)]
        [Display(Name = "Maximo señales pasadas por vista", GroupName = "04. Visual", Order = 2)]
        public int HistorySignals { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Panel de movimiento", GroupName = "04. Visual", Order = 3)]
        public bool ShowToolbar { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Posición del panel", GroupName = "04. Visual", Order = 8)]
        public PhaseTestPanelPlacement PanelPlacement { get; set; }

        [NinjaScriptProperty]
        [Range(10, 22)]
        [Display(Name = "Tamaño de fuente del panel", GroupName = "04. Visual", Order = 9)]
        public int PanelTextSize { get; set; }

        [NinjaScriptProperty]
        [Range(0, 2000)]
        [Display(Name = "Offset marcador (ticks)", GroupName = "04. Visual", Order = 4)]
        public int MarkerOffsetTicks { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Offset en ATR", GroupName = "04. Visual", Order = 5)]
        public bool UseAtrMarkerOffset { get; set; }

        [NinjaScriptProperty]
        [Range(0.0, 20.0)]
        [Display(Name = "Multiplicador ATR", GroupName = "04. Visual", Order = 6)]
        public double MarkerOffsetAtrMultiple { get; set; }

        [Range(1, 500)]
        [Display(Name = "Periodo ATR", Description = "Periodo del ATR utilizado para separar los marcadores del máximo o mínimo.", GroupName = "04. Visual", Order = 7)]
        public int MarkerAtrPeriod { get; set; }

        // Propiedades visuales nativas del panel de propiedades de NinjaTrader.
        // No intervienen en la identidad, la geometría ni los filtros de las retículas.
        [Range(0.5, 10.0)]
        [Display(Name = "Grosor vertical · seleccionadas", GroupName = "05. Estilo de señales", Order = 1)]
        public double SignalVerticalWidth { get; set; }

        [Display(Name = "Estilo línea vertical", GroupName = "05. Estilo de señales", Order = 2)]
        public NinjaTrader.Gui.DashStyleHelper SignalVerticalStyle { get; set; }

        [Range(0.5, 10.0)]
        [Display(Name = "Grosor horizontal · seleccionadas", GroupName = "05. Estilo de señales", Order = 3)]
        public double SignalHorizontalWidth { get; set; }

        [Display(Name = "Estilo línea horizontal", GroupName = "05. Estilo de señales", Order = 4)]
        public NinjaTrader.Gui.DashStyleHelper SignalHorizontalStyle { get; set; }

        [Range(2, 40)]
        [Display(Name = "Tamaño punto", Description = "Diámetro visual del marcador en píxeles.", GroupName = "05. Estilo de señales", Order = 5)]
        public int SignalDotSize { get; set; }

        [Range(6, 36)]
        [Display(Name = "Tamaño fuente marcadores", GroupName = "05. Estilo de señales", Order = 6)]
        public int SignalLabelFontSize { get; set; }

        private double mutedVerticalWidth = 1.0;

        [Range(1.0, 10.0)]
        [Display(Name = "Grosor vertical · sombra", GroupName = "05. Estilo de señales", Order = 7)]
        public double MutedVerticalWidth
        {
            get { return mutedVerticalWidth; }
            set { mutedVerticalWidth = double.IsNaN(value) ? 1.0 : Math.Max(1.0, Math.Min(10.0, value)); }
        }

        private double mutedHorizontalWidth = 1.0;

        [Range(1.0, 10.0)]
        [Display(Name = "Grosor horizontal · sombra", GroupName = "05. Estilo de señales", Order = 8)]
        public double MutedHorizontalWidth
        {
            get { return mutedHorizontalWidth; }
            set { mutedHorizontalWidth = double.IsNaN(value) ? 1.0 : Math.Max(1.0, Math.Min(10.0, value)); }
        }

        [Range(2, 40)]
        [Display(Name = "Tamaño punto · sombra", GroupName = "05. Estilo de señales", Order = 9)]
        public int MutedDotSize { get; set; }

        [XmlIgnore]
        [Display(Name = "Color binaria 1", GroupName = "05. Estilo de señales", Order = 10)]
        public WpfBrush SignalBuyBrush { get; set; }
        [Browsable(false)]
        public string SignalBuyBrushSerialize
        {
            get { return Serialize.BrushToString(SignalBuyBrush); }
            set { SignalBuyBrush = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Color binaria 2", GroupName = "05. Estilo de señales", Order = 11)]
        public WpfBrush SignalSellBrush { get; set; }
        [Browsable(false)]
        public string SignalSellBrushSerialize
        {
            get { return Serialize.BrushToString(SignalSellBrush); }
            set { SignalSellBrush = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Color señales sombra", GroupName = "05. Estilo de señales", Order = 12)]
        public WpfBrush SignalMutedBrush { get; set; }
        [Browsable(false)]
        public string SignalMutedBrushSerialize
        {
            get { return Serialize.BrushToString(SignalMutedBrush); }
            set { SignalMutedBrush = Serialize.StringToBrush(value); }
        }

        [Display(Name = "Destacar ciclo ancla", GroupName = "06. Ciclo ancla", Order = 1)]
        public bool HighlightAnchorCycle { get; set; }

        [XmlIgnore]
        [Display(Name = "Color de fondo", GroupName = "06. Ciclo ancla", Order = 2)]
        public WpfBrush AnchorCycleBrush { get; set; }
        [Browsable(false)]
        public string AnchorCycleBrushSerialize
        {
            get { return Serialize.BrushToString(AnchorCycleBrush); }
            set { AnchorCycleBrush = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Opacidad (%)", GroupName = "06. Ciclo ancla", Order = 3)]
        public int AnchorCycleOpacity { get; set; }

        // Escala porcentual de Butterworth, aplicada a la MA elegida (sin su filtro).
        // 100 % del nivel = abs(MA) * PercentBaseRange / 100.
        // Nivel +/-L = MA +/- (L/100) * distancia 100 %.
        [NinjaScriptProperty]
        [Display(Name = "Mostrar niveles MA", GroupName = "07. Niveles porcentuales", Order = 1)]
        public bool ShowPercentBands { get; set; }

        [NinjaScriptProperty]
        [Range(0.001, 20.0)]
        [Display(Name = "Distancia base 100% (% MA)", Description = "Porcentaje del valor de la media que equivale al nivel 100. No es ATR.", GroupName = "07. Niveles porcentuales", Order = 2)]
        public double PercentBaseRange { get; set; }

        [NinjaScriptProperty]
        [Range(0.1, 500.0)]
        [Display(Name = "Zona desde (%)", Description = "Umbral interior de la zona, simetrico sobre y bajo la MA.", GroupName = "07. Niveles porcentuales", Order = 3)]
        public double PercentTestLevel { get; set; }

        [NinjaScriptProperty]
        [Range(0.1, 500.0)]
        [Display(Name = "Zona hasta (%)", Description = "Umbral exterior de la zona. Debe superar el umbral interior.", GroupName = "07. Niveles porcentuales", Order = 4)]
        public double PercentZoneUpperLevel { get; set; }

        [Range(1, 8)]
        [Display(Name = "Grosor de limites", GroupName = "07. Niveles porcentuales", Order = 5)]
        public int PercentBandWidth { get; set; }

        [Display(Name = "Estilo de limites", GroupName = "07. Niveles porcentuales", Order = 6)]
        public NinjaTrader.Gui.DashStyleHelper PercentBandStyle { get; set; }

        [XmlIgnore]
        [Display(Name = "Color de limites", GroupName = "07. Niveles porcentuales", Order = 7)]
        public WpfBrush PercentBandBrush { get; set; }
        [Browsable(false)]
        public string PercentBandBrushSerialize
        {
            get { return Serialize.BrushToString(PercentBandBrush); }
            set { PercentBandBrush = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Color de relleno", GroupName = "07. Niveles porcentuales", Order = 8)]
        public WpfBrush PercentZoneBrush { get; set; }
        [Browsable(false)]
        public string PercentZoneBrushSerialize
        {
            get { return Serialize.BrushToString(PercentZoneBrush); }
            set { PercentZoneBrush = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [Display(Name = "Opacidad relleno (%)", GroupName = "07. Niveles porcentuales", Order = 9)]
        public int PercentZoneOpacity { get; set; }

        private static WpfBrush MakeBrush(byte a, byte r, byte g, byte b)
        {
            var brush = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromArgb(a,r,g,b));
            brush.Freeze();
            return brush;
        }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "ForcePhaseLab";
                Description = "v1.0.29 · Estudio causal de espaciado y fase por giros OHLC; aplicacion manual; conserva v1.0.28.";
                IsOverlay = true;
                DrawOnPricePanel = true;
                IsAutoScale = false;
                Calculate = Calculate.OnBarClose;
                IsSuspendedWhileInactive = true;
                MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
                SeparationBars = 9;
                StudyMinBars = 4;
                StudyMaxBars = 60;
                BaseBinary = 1;
                AnchorAIndex = -1;
                AnchorBIndex = -1;
                ShowA = true;
                ShowB = true;
                ShowWithTrend = true;
                ShowAgainstTrend = false;
                AverageType = PhaseTestAverageType.HMA;
                AveragePeriod = 21;
                ShowAverage = true;
                TrendToleranceTicks = 4;
                TrendFilterMode = PhaseTestTrendFilterMode.PosicionMA;
                SlopeLookback = 3;
                SlopeThresholdAtr = 0.06;
                SlopeAtrPeriod = 14;
                AverageLineWidth = 2;
                SlopeUpBrush = MakeBrush(255,63,192,112);
                SlopeDownBrush = MakeBrush(255,230,80,80);
                SlopeFlatBrush = MakeBrush(255,170,170,170);
                FutureSignals = 5;
                HistorySignals = 100;
                ShowToolbar = true;
                PanelPlacement = PhaseTestPanelPlacement.ArribaIzquierda;
                PanelTextSize = 13;
                MarkerOffsetTicks = 20;
                UseAtrMarkerOffset = false;
                MarkerOffsetAtrMultiple = 1.0;
                MarkerAtrPeriod = 7;
                SignalVerticalWidth = 1.5;
                SignalVerticalStyle = NinjaTrader.Gui.DashStyleHelper.Dash;
                SignalHorizontalWidth = 1.5;
                SignalHorizontalStyle = NinjaTrader.Gui.DashStyleHelper.Dash;
                SignalDotSize = 11;
                SignalLabelFontSize = 12;
                MutedVerticalWidth = 1.0;
                MutedHorizontalWidth = 1.0;
                MutedDotSize = 7;
                SignalBuyBrush = MakeBrush(255,26,209,59);
                SignalSellBrush = MakeBrush(255,250,46,56);
                SignalMutedBrush = MakeBrush(140,140,140,140);
                HighlightAnchorCycle = true;
                AnchorCycleBrush = MakeBrush(255,234,179,8);
                AnchorCycleOpacity = 12;
                ShowPercentBands = true;
                PercentBaseRange = 1.0;
                PercentTestLevel = 75.0;
                PercentZoneUpperLevel = 100.0;
                PercentBandWidth = 2;
                PercentBandStyle = NinjaTrader.Gui.DashStyleHelper.Dash;
                PercentBandBrush = MakeBrush(230,204,153,255);
                PercentZoneBrush = MakeBrush(255,180,130,230);
                PercentZoneOpacity = 12;
                AnchorProfile = "Principal";
                AnchorStartStamp = string.Empty;
                AnchorEndStamp = string.Empty;
                AnchorStartPrice = 0;
                AnchorEndPrice = 0;
                AddPlot(WpfBrushes.Gainsboro, "MediaFiltrado");
            }
            else if (State == State.DataLoaded)
            {
                activeAverage = CreateNativeAverage(AverageType, AveragePeriod);
                slopeAtr = ATR(SlopeAtrPeriod);
                markerAtrCache.Clear();
                cachedMarkerAtrPeriod = -1;
                Plots[0].Width = AverageLineWidth;
                applicationTimeZone = NinjaTrader.Core.Globals.GeneralOptions.TimeZoneInfo;
                nominalSeconds = BarsPeriod.BarsPeriodType == BarsPeriodType.Minute
                    ? 60.0 * BarsPeriod.Value : BarsPeriod.BarsPeriodType == BarsPeriodType.Second
                    ? BarsPeriod.Value : 0.0;
            }
            else if (State == State.Historical)
            {
                if (ChartControl != null)
                    ChartControl.Dispatcher.InvokeAsync(() => InstallUserInterface());
            }
            else if (State == State.Terminated)
            {
                // No consultar el objeto de dibujo ni las barras al desmontar el chart.
                // Solo finalizar un snapshot valido que ya se haya capturado.
                lock (anchorGate) { if (anchorsInitialized && anchorDirty) WriteAnchorFile(); }
                ChartControl cc = ChartControl;
                if (cc != null)
                    cc.Dispatcher.InvokeAsync(() => UninstallUserInterface());
            }
        }

        private Indicator CreateNativeAverage(PhaseTestAverageType type, int period)
        {
            switch (type)
            {
                case PhaseTestAverageType.WMA: return WMA(period);
                case PhaseTestAverageType.EMA: return EMA(period);
                case PhaseTestAverageType.SMA: return SMA(period);
                default: return HMA(period);
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < 1 || activeAverage == null)
            {
                lastClosedIndex = CurrentBar;
                return;
            }
            double ma = activeAverage[0];
            Values[0][0] = ShowAverage ? ma : double.NaN;
            lastClosedIndex = CurrentBar;
            // Forzar el cálculo del ATR normalizador antes de consultar su serie histórica.
            if (slopeAtr != null) { double latestAtr = slopeAtr[0]; }
            if (ShowAverage)
                PlotBrushes[0][0] = SlopeBrushFor(SlopeTrendAt(CurrentBar));
        }

        private void InstallUserInterface()
        {
            if (ChartControl == null || ChartPanel == null || toolbar != null)
                return;

            if (!ShowToolbar)
                return;
            toolbar = new Grid {
                Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromArgb(230, 20, 23, 31)),
                SnapsToDevicePixels = true
            };
            ApplyToolbarAppearance();
            StackPanel vertical = new StackPanel { Orientation = Orientation.Vertical };
            WrapPanel first = new WrapPanel { Orientation = Orientation.Horizontal };
            TextBlock head = new TextBlock { Text = "PHASE TEST   ", Foreground = WpfBrushes.White,
                VerticalAlignment = VerticalAlignment.Center, FontWeight = FontWeights.SemiBold };
            first.Children.Add(head);
            chkA = CreateCheckBox("Mostrar A", ShowA, v => ShowA = v); first.Children.Add(chkA);
            chkB = CreateCheckBox("Mostrar B", ShowB, v => ShowB = v); first.Children.Add(chkB);
            chkWith = CreateCheckBox("Favor", ShowWithTrend, v => ShowWithTrend = v); first.Children.Add(chkWith);
            chkAgainst = CreateCheckBox("Contra", ShowAgainstTrend, v => ShowAgainstTrend = v); first.Children.Add(chkAgainst);
            vertical.Children.Add(first);

            // Navegación compacta; se agrupa cada pareja de flechas para que
            // los textos Inicio/Todo/Fin no se repitan seis veces.
            WrapPanel second = new WrapPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(2, 1, 2, 1) };
            second.Children.Add(NewButton("Dibujar aquí", PlaceVisibleAnchor));
            second.Children.Add(NewNavigationGroup("Inicio", () => MoveOrigin(-1), () => MoveOrigin(1)));
            second.Children.Add(NewNavigationGroup("Todo", () => MoveBoth(-1), () => MoveBoth(1)));
            second.Children.Add(NewNavigationGroup("Fin", () => MoveSecond(-1), () => MoveSecond(1)));
            vertical.Children.Add(second);

            // Estudio sobre Bars.GetHigh/Low/Close ya cargados. Ninguna exportacion TXT.
            var studyRow = new WrapPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(3, 1, 3, 0) };
            studyRow.Children.Add(NewButton("Estudiar ancla", RunAnchorStudy));
            anchorStudyApplyButton = NewButton("Aplicar estudio", ApplyAnchorStudy);
            anchorStudyApplyButton.IsEnabled = false;
            studyRow.Children.Add(anchorStudyApplyButton);
            vertical.Children.Add(studyRow);
            anchorStudyStatusLabel = new TextBlock { Text = "Estudio: pendiente · el ancla no se modifica.",
                Foreground = WpfBrushes.LightGray, TextWrapping = System.Windows.TextWrapping.Wrap,
                Margin = new Thickness(4, 0, 4, 1), MaxWidth = 520 };
            vertical.Children.Add(anchorStudyStatusLabel);

            // Un solo ajuste de offset A/B: modo, periodo ATR y cantidad.
            // Los dos campos se confirman juntos con Aplicar o Enter; Tab no confirma.
            WrapPanel offsetRow = new WrapPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(3, 2, 3, 0) };
            offsetRow.Children.Add(new TextBlock { Text = "Offset dot  ", Foreground = WpfBrushes.White,
                VerticalAlignment = VerticalAlignment.Center, FontSize = PanelTextSize });
            ComboBox offsetMode = new ComboBox { Width = 70, MinHeight = 25, Margin = new Thickness(0, 0, 4, 0), FontSize = PanelTextSize };
            offsetMode.Items.Add("Ticks");
            offsetMode.Items.Add("ATR");
            offsetMode.SelectedIndex = UseAtrMarkerOffset ? 1 : 0;
            offsetModeSelector = offsetMode;
            TextBlock periodLabel = new TextBlock { Text = "Periodo ", Foreground = WpfBrushes.White,
                VerticalAlignment = VerticalAlignment.Center, FontSize = PanelTextSize };
            TextBox atrPeriodValue = new TextBox { Width = 40, MinHeight = 25, FontSize = PanelTextSize,
                Margin = new Thickness(0, 0, 5, 0), ToolTip = "Periodo ATR (1–500)",
                VerticalContentAlignment = VerticalAlignment.Center, TextAlignment = System.Windows.TextAlignment.Right,
                Focusable = true, IsTabStop = true };
            TextBlock quantityLabel = new TextBlock { Text = "× ", Foreground = WpfBrushes.White,
                VerticalAlignment = VerticalAlignment.Center, FontSize = PanelTextSize };
            TextBox offsetValue = new TextBox { Width = 55, MinHeight = 25, FontSize = PanelTextSize,
                VerticalContentAlignment = VerticalAlignment.Center, TextAlignment = System.Windows.TextAlignment.Right,
                Focusable = true, IsTabStop = true };
            Action loadOffsetValue = () => offsetValue.Text = UseAtrMarkerOffset
                ? MarkerOffsetAtrMultiple.ToString("0.###############", CultureInfo.CurrentCulture)
                : MarkerOffsetTicks.ToString(CultureInfo.InvariantCulture);
            Action loadAtrPeriod = () => atrPeriodValue.Text = MarkerAtrPeriod.ToString(CultureInfo.InvariantCulture);
            Action refreshOffsetMode = () =>
            {
                periodLabel.Visibility = atrPeriodValue.Visibility = quantityLabel.Visibility = UseAtrMarkerOffset
                    ? System.Windows.Visibility.Visible : System.Windows.Visibility.Collapsed;
                offsetValue.ToolTip = UseAtrMarkerOffset ? "Multiplicador ATR (admite decimales)" : "Offset en ticks";
            };
            Action commitOffset = () =>
            {
                if (syncingTemplatePanel || templateLoading) return;
                double value;
                string raw = offsetValue.Text.Trim().Replace(',', '.');
                if (double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out value)
                    && !double.IsNaN(value) && !double.IsInfinity(value))
                {
                    if (UseAtrMarkerOffset)
                        MarkerOffsetAtrMultiple = Math.Max(0.0, Math.Min(20.0, value));
                    else
                        MarkerOffsetTicks = (int)Math.Round(Math.Max(0.0, Math.Min(2000.0, value)), MidpointRounding.AwayFromZero);
                }
                int period;
                if (UseAtrMarkerOffset && int.TryParse(atrPeriodValue.Text.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out period))
                    MarkerAtrPeriod = Math.Max(1, Math.Min(500, period));
                loadOffsetValue();
                loadAtrPeriod();
                Repaint();
            };
            offsetMode.SelectionChanged += (s,e) =>
            {
                if (syncingTemplatePanel || templateLoading) { refreshOffsetMode(); return; }
                // Conservar los valores de la unidad anterior al cambiar de modo.
                commitOffset();
                UseAtrMarkerOffset = offsetMode.SelectedIndex == 1;
                loadOffsetValue();
                loadAtrPeriod();
                refreshOffsetMode();
                Repaint();
            };
            offsetEditor = offsetValue;
            atrPeriodEditor = atrPeriodValue;
            commitOffsetEditor = commitAtrPeriodEditor = commitOffset;
            restoreOffsetEditor = () => { loadOffsetValue(); refreshOffsetMode(); };
            restoreAtrPeriodEditor = loadAtrPeriod;
            loadOffsetValue();
            loadAtrPeriod();
            refreshOffsetMode();
            foreach (TextBox editor in new[] { atrPeriodValue, offsetValue })
            {
                TextBox field = editor;
                field.PreviewMouseLeftButtonDown += (s,e) =>
                {
                    if (field.IsKeyboardFocusWithin) return;
                    e.Handled = true;
                    field.Focus();
                    WpfInput.Keyboard.Focus(field);
                    field.SelectAll();
                };
                field.GotKeyboardFocus += (s,e) => field.SelectAll();
            }
            offsetRow.Children.Add(offsetMode);
            offsetRow.Children.Add(periodLabel);
            offsetRow.Children.Add(atrPeriodValue);
            offsetRow.Children.Add(quantityLabel);
            offsetRow.Children.Add(offsetValue);
            offsetRow.Children.Add(NewButton("Aplicar", commitOffset));
            vertical.Children.Add(offsetRow);
            WrapPanel toleranceRow = new WrapPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(3, 2, 3, 0) };
            toleranceRow.Children.Add(new TextBlock { Text = "Holgura MA (ticks)  ", Foreground = WpfBrushes.White,
                VerticalAlignment = VerticalAlignment.Center, FontSize = PanelTextSize });
            TextBox toleranceValue = new TextBox { Width = 55, MinHeight = 25, FontSize = PanelTextSize,
                VerticalContentAlignment = VerticalAlignment.Center, TextAlignment = System.Windows.TextAlignment.Right,
                Focusable = true, IsTabStop = true };
            Action loadTolerance = () => toleranceValue.Text = TrendToleranceTicks.ToString(CultureInfo.InvariantCulture);
            Action commitTolerance = () =>
            {
                if (syncingTemplatePanel || templateLoading) return;
                int value;
                if (int.TryParse(toleranceValue.Text.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out value))
                    TrendToleranceTicks = Math.Max(0, Math.Min(2000, value));
                loadTolerance();
                Repaint();
            };
            toleranceEditor = toleranceValue;
            commitToleranceEditor = commitTolerance;
            restoreToleranceEditor = loadTolerance;
            loadTolerance();
            toleranceValue.PreviewMouseLeftButtonDown += (s,e) =>
            {
                if (toleranceValue.IsKeyboardFocusWithin) return;
                e.Handled = true;
                toleranceValue.Focus();
                WpfInput.Keyboard.Focus(toleranceValue);
                toleranceValue.SelectAll();
            };
            toleranceValue.GotKeyboardFocus += (s,e) => toleranceValue.SelectAll();
            toleranceValue.LostKeyboardFocus += (s,e) => commitTolerance();
            toleranceRow.Children.Add(toleranceValue);
            toleranceRow.Children.Add(NewButton("Aplicar", commitTolerance));
            vertical.Children.Add(toleranceRow);

            // Zona visual simetrica +/- [desde, hasta]; no conmuta entre A y B.
            WrapPanel percentRow = new WrapPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(3, 2, 3, 0) };
            chkPercentBands = CreateCheckBox("Zonas %", ShowPercentBands, v => ShowPercentBands = v);
            percentRow.Children.Add(chkPercentBands);
            percentRow.Children.Add(new TextBlock { Text = "100% base  ", Foreground = WpfBrushes.White,
                VerticalAlignment = VerticalAlignment.Center, FontSize = PanelTextSize });
            TextBox percentBase = new TextBox { Width = 55, MinHeight = 25, FontSize = PanelTextSize,
                VerticalContentAlignment = VerticalAlignment.Center, TextAlignment = System.Windows.TextAlignment.Right,
                ToolTip = "1,0 significa que 100% de distancia equivale al 1% del valor de la media.",
                Focusable = true, IsTabStop = true };
            percentRow.Children.Add(percentBase);
            percentRow.Children.Add(new TextBlock { Text = "% MA   Desde  ", Foreground = WpfBrushes.White,
                VerticalAlignment = VerticalAlignment.Center, FontSize = PanelTextSize });
            TextBox percentLevel = new TextBox { Width = 55, MinHeight = 25, FontSize = PanelTextSize,
                VerticalContentAlignment = VerticalAlignment.Center, TextAlignment = System.Windows.TextAlignment.Right,
                ToolTip = "Porcentaje interior de la zona de sobrecompra y sobreventa (p. ej. 75).",
                Focusable = true, IsTabStop = true };
            percentRow.Children.Add(percentLevel);
            percentRow.Children.Add(new TextBlock { Text = "%   Hasta  ", Foreground = WpfBrushes.White,
                VerticalAlignment = VerticalAlignment.Center, FontSize = PanelTextSize });
            TextBox percentUpper = new TextBox { Width = 55, MinHeight = 25, FontSize = PanelTextSize,
                VerticalContentAlignment = VerticalAlignment.Center, TextAlignment = System.Windows.TextAlignment.Right,
                ToolTip = "Porcentaje exterior de la zona (p. ej. 100). Tiene que superar el interior.",
                Focusable = true, IsTabStop = true };
            percentRow.Children.Add(percentUpper);
            percentRow.Children.Add(new TextBlock { Text = "%  ", Foreground = WpfBrushes.White,
                VerticalAlignment = VerticalAlignment.Center, FontSize = PanelTextSize });
            Action restorePercents = () => {
                percentBase.Text = PercentBaseRange.ToString("0.###############", CultureInfo.CurrentCulture);
                percentLevel.Text = PercentTestLevel.ToString("0.###############", CultureInfo.CurrentCulture);
                percentUpper.Text = PercentZoneUpperLevel.ToString("0.###############", CultureInfo.CurrentCulture);
            };
            Action commitPercents = () => {
                if (syncingTemplatePanel || templateLoading) return;
                double basis, level, upper;
                bool validBase = double.TryParse(percentBase.Text.Trim().Replace(',', '.'),
                    NumberStyles.Float, CultureInfo.InvariantCulture, out basis);
                bool validLevel = double.TryParse(percentLevel.Text.Trim().Replace(',', '.'),
                    NumberStyles.Float, CultureInfo.InvariantCulture, out level);
                bool validUpper = double.TryParse(percentUpper.Text.Trim().Replace(',', '.'),
                    NumberStyles.Float, CultureInfo.InvariantCulture, out upper);
                if (validBase && validLevel && validUpper && !double.IsNaN(basis) && !double.IsInfinity(basis)
                    && !double.IsNaN(level) && !double.IsInfinity(level)
                    && !double.IsNaN(upper) && !double.IsInfinity(upper)
                    && basis >= 0.001 && basis <= 20.0 && level >= 0.1 && upper <= 500.0 && upper > level)
                {
                    PercentBaseRange = basis;
                    PercentTestLevel = level;
                    PercentZoneUpperLevel = upper;
                    if (templateStatusLabel != null)
                        templateStatusLabel.Text = "Zona: " + level.ToString("0.##", CultureInfo.CurrentCulture)
                            + "–" + upper.ToString("0.##", CultureInfo.CurrentCulture) + "%";
                }
                else if (templateStatusLabel != null)
                    templateStatusLabel.Text = "Zona no valida: Hasta debe superar Desde (0,1–500%).";
                restorePercents();
                Repaint();
            };
            percentBaseEditor = percentBase;
            percentLevelEditor = percentLevel;
            percentUpperEditor = percentUpper;
            commitPercentEditors = commitPercents;
            restorePercentEditors = restorePercents;
            restorePercents();
            foreach (TextBox field in new[] { percentBase, percentLevel, percentUpper })
            {
                TextBox input = field;
                input.PreviewMouseLeftButtonDown += (s,e) => {
                    if (input.IsKeyboardFocusWithin) return;
                    e.Handled = true; input.Focus(); WpfInput.Keyboard.Focus(input); input.SelectAll();
                };
                input.GotKeyboardFocus += (s,e) => input.SelectAll();
            }
            percentRow.Children.Add(NewButton("Aplicar", commitPercents));
            vertical.Children.Add(percentRow);

            WrapPanel templateRow = new WrapPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(3, 2, 3, 0) };
            templateRow.Children.Add(NewButton("Guardar template", SaveFullTemplate));
            templateRow.Children.Add(NewButton("Cargar template", LoadFullTemplate));
            vertical.Children.Add(templateRow);
            templateStatusLabel = new TextBlock { Foreground = WpfBrushes.LightGray, FontSize = PanelTextSize,
                Margin = new Thickness(3, 0, 3, 0), TextWrapping = System.Windows.TextWrapping.Wrap, MaxWidth = 600 };
            vertical.Children.Add(templateStatusLabel);

            toolbarLabel = new TextBlock { Text = "Selecciona y arrastra la línea nativa o sus extremos. B = A+1.",
                Foreground = WpfBrushes.LightGray, FontSize = PanelTextSize, Margin = new Thickness(3, 2, 0, 2) };
            vertical.Children.Add(toolbarLabel);
            toolbar.Children.Add(vertical);
            UserControlCollection.Add(toolbar);
            ChartControl.SizeChanged += ToolbarChart_SizeChanged;
            ApplyToolbarAppearance();
            // Captura antes de los atajos de instrumento del chart. Solo nuestro editor.
            offsetInputManager = WpfInput.InputManager.Current;
            offsetInputManager.PreProcessInput += OffsetInput_PreProcessInput;
        }

        private void ToolbarChart_SizeChanged(object sender, System.Windows.SizeChangedEventArgs e)
        {
            if (toolbar != null) ApplyToolbarAppearance();
        }

        private void ApplyToolbarAppearance()
        {
            if (toolbar == null) return;
            int size = Math.Max(10, Math.Min(22, PanelTextSize));
            toolbar.SetValue(System.Windows.Documents.TextElement.FontSizeProperty, (double)size);
            bool right = PanelPlacement == PhaseTestPanelPlacement.ArribaDerecha || PanelPlacement == PhaseTestPanelPlacement.AbajoDerecha;
            bool center = PanelPlacement == PhaseTestPanelPlacement.ArribaCentro || PanelPlacement == PhaseTestPanelPlacement.AbajoCentro;
            bool bottom = PanelPlacement == PhaseTestPanelPlacement.AbajoIzquierda || PanelPlacement == PhaseTestPanelPlacement.AbajoCentro || PanelPlacement == PhaseTestPanelPlacement.AbajoDerecha;
            toolbar.HorizontalAlignment = center ? HorizontalAlignment.Center : right ? HorizontalAlignment.Right : HorizontalAlignment.Left;
            toolbar.VerticalAlignment = bottom ? VerticalAlignment.Bottom : VerticalAlignment.Top;
            toolbar.Margin = new Thickness(right || center ? 0 : 12, bottom ? 0 : 35,
                right ? 12 : 0, bottom ? 35 : 0);
            double chartWidth = ChartControl == null ? 650 : ChartControl.ActualWidth;
            toolbar.MaxWidth = Math.Max(230, chartWidth > 80 ? chartWidth - 32 : 650);
            // Aplicar también a los controles creados antes de cargar una plantilla.
            ApplyToolbarFont(toolbar, size);
            if (offsetModeSelector != null) offsetModeSelector.Width = Math.Max(70, size * 5.0);
            if (atrPeriodEditor != null) atrPeriodEditor.Width = Math.Max(40, size * 2.8);
            if (offsetEditor != null) offsetEditor.Width = Math.Max(55, size * 3.4);
            if (toleranceEditor != null) toleranceEditor.Width = Math.Max(55, size * 3.4);
            if (percentBaseEditor != null) percentBaseEditor.Width = Math.Max(55, size * 3.4);
            if (percentLevelEditor != null) percentLevelEditor.Width = Math.Max(55, size * 3.4);
            if (percentUpperEditor != null) percentUpperEditor.Width = Math.Max(55, size * 3.4);
        }

        private static void ApplyToolbarFont(DependencyObject root, int size)
        {
            if (root == null) return;
            var control = root as Control;
            if (control != null) control.FontSize = size;
            var text = root as TextBlock;
            if (text != null) text.FontSize = size;
            int count = System.Windows.Media.VisualTreeHelper.GetChildrenCount(root);
            for (int i = 0; i < count; i++) ApplyToolbarFont(System.Windows.Media.VisualTreeHelper.GetChild(root, i), size);
        }

        private StackPanel NewNavigationGroup(string name, Action left, Action right)
        {
            var group = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(4, 0, 1, 0),
                VerticalAlignment = VerticalAlignment.Center };
            group.Children.Add(new TextBlock { Text = name, Foreground = WpfBrushes.LightGray,
                FontSize = PanelTextSize, VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 3, 0) });
            Button backwards = NewButton("◀", left);
            backwards.ToolTip = name + " · una barra atrás";
            backwards.MinWidth = Math.Max(22, PanelTextSize + 9);
            group.Children.Add(backwards);
            Button forwards = NewButton("▶", right);
            forwards.ToolTip = name + " · una barra adelante";
            forwards.MinWidth = Math.Max(22, PanelTextSize + 9);
            group.Children.Add(forwards);
            return group;
        }

        private static void ReplaceOffsetSelection(TextBox box, string text)
        {
            int start = box.SelectionStart;
            box.SelectedText = text;
            box.CaretIndex = start + text.Length;
        }

        private void InsertOffsetText(TextBox box, string text)
        {
            string proposed = box.Text.Remove(box.SelectionStart, box.SelectionLength)
                .Insert(box.SelectionStart, text).Replace(',', '.');
            int separators = 0;
            foreach (char c in proposed)
            {
                if (c >= '0' && c <= '9') continue;
                if (box == offsetEditor && UseAtrMarkerOffset && c == '.' && ++separators == 1) continue;
                return;
            }
            ReplaceOffsetSelection(box, text);
        }

        private void OffsetInput_PreProcessInput(object sender, WpfInput.PreProcessInputEventArgs e)
        {
            if (e == null || e.StagingItem == null || toolbar == null)
                return;
            TextBox box = atrPeriodEditor != null && atrPeriodEditor.IsKeyboardFocusWithin ? atrPeriodEditor
                : toleranceEditor != null && toleranceEditor.IsKeyboardFocusWithin ? toleranceEditor
                : percentBaseEditor != null && percentBaseEditor.IsKeyboardFocusWithin ? percentBaseEditor
                : percentLevelEditor != null && percentLevelEditor.IsKeyboardFocusWithin ? percentLevelEditor
                : percentUpperEditor != null && percentUpperEditor.IsKeyboardFocusWithin ? percentUpperEditor
                : offsetEditor;
            if (box == null || !box.IsVisible || !box.IsEnabled || !box.IsKeyboardFocusWithin)
                return;
            // Bloquea el atajo global antes de PreviewKeyDown del ChartWindow.
            WpfInput.KeyEventArgs args = e.StagingItem.Input as WpfInput.KeyEventArgs;
            if (args == null || args.RoutedEvent != WpfInput.Keyboard.PreviewKeyDownEvent || args.Handled)
                return;
            args.Handled = true;
            WpfInput.Key key = args.Key == WpfInput.Key.System ? args.SystemKey : args.Key;
            WpfInput.ModifierKeys mods = WpfInput.Keyboard.Modifiers;
            bool ctrl = (mods & WpfInput.ModifierKeys.Control) != WpfInput.ModifierKeys.None;
            bool shift = (mods & WpfInput.ModifierKeys.Shift) != WpfInput.ModifierKeys.None;
            if ((mods & (WpfInput.ModifierKeys.Alt | WpfInput.ModifierKeys.Windows)) != WpfInput.ModifierKeys.None) return;
            if (ctrl)
            {
                try
                {
                    if (key == WpfInput.Key.A) box.SelectAll();
                    else if (key == WpfInput.Key.C && box.SelectionLength > 0)
                        System.Windows.Clipboard.SetText(box.SelectedText);
                    else if (key == WpfInput.Key.X && box.SelectionLength > 0)
                    {
                        System.Windows.Clipboard.SetText(box.SelectedText);
                        ReplaceOffsetSelection(box, string.Empty);
                    }
                    else if (key == WpfInput.Key.V && System.Windows.Clipboard.ContainsText())
                        InsertOffsetText(box, System.Windows.Clipboard.GetText().Trim());
                    else if (key == WpfInput.Key.Z && box.CanUndo) box.Undo();
                    else if (key == WpfInput.Key.Y && box.CanRedo) box.Redo();
                }
                catch { /* Portapapeles ocupado. */ }
                return;
            }
            if (key == WpfInput.Key.Enter || key == WpfInput.Key.Return)
            {
                Action commit = box == atrPeriodEditor ? commitAtrPeriodEditor : box == toleranceEditor ? commitToleranceEditor
                    : (box == percentBaseEditor || box == percentLevelEditor || box == percentUpperEditor) ? commitPercentEditors : commitOffsetEditor;
                if (commit != null) commit();
                box.SelectAll();
                return;
            }
            if (key == WpfInput.Key.Escape)
            {
                Action restore = box == atrPeriodEditor ? restoreAtrPeriodEditor : box == toleranceEditor ? restoreToleranceEditor
                    : (box == percentBaseEditor || box == percentLevelEditor || box == percentUpperEditor) ? restorePercentEditors : restoreOffsetEditor;
                if (restore != null) restore();
                box.SelectAll();
                return;
            }
            if (key == WpfInput.Key.Tab)
            {
                box.MoveFocus(new WpfInput.TraversalRequest(shift ? WpfInput.FocusNavigationDirection.Previous : WpfInput.FocusNavigationDirection.Next));
                return;
            }
            if (key == WpfInput.Key.Back || key == WpfInput.Key.Delete)
            {
                if (box.SelectionLength == 0)
                {
                    if (key == WpfInput.Key.Back && box.CaretIndex > 0)
                        box.Select(box.CaretIndex - 1, 1);
                    else if (key == WpfInput.Key.Delete && box.CaretIndex < box.Text.Length)
                        box.Select(box.CaretIndex, 1);
                }
                if (box.SelectionLength > 0) ReplaceOffsetSelection(box, string.Empty);
                return;
            }
            if (key == WpfInput.Key.Left || key == WpfInput.Key.Right || key == WpfInput.Key.Home || key == WpfInput.Key.End)
            {
                int caret = box.CaretIndex;
                int target = key == WpfInput.Key.Home ? 0 : key == WpfInput.Key.End ? box.Text.Length
                    : key == WpfInput.Key.Left ? Math.Max(0, caret - 1) : Math.Min(box.Text.Length, caret + 1);
                if (!shift)
                {
                    if (box.SelectionLength > 0 && key == WpfInput.Key.Left) target = box.SelectionStart;
                    if (box.SelectionLength > 0 && key == WpfInput.Key.Right) target = box.SelectionStart + box.SelectionLength;
                    box.Select(target, 0);
                }
                else box.Select(Math.Min(caret, target), Math.Abs(target - caret));
                return;
            }
            int k = (int)key;
            if (k >= (int)WpfInput.Key.D0 && k <= (int)WpfInput.Key.D9)
                InsertOffsetText(box, (k - (int)WpfInput.Key.D0).ToString(CultureInfo.InvariantCulture));
            else if (k >= (int)WpfInput.Key.NumPad0 && k <= (int)WpfInput.Key.NumPad9)
                InsertOffsetText(box, (k - (int)WpfInput.Key.NumPad0).ToString(CultureInfo.InvariantCulture));
            else if (((box == offsetEditor && UseAtrMarkerOffset) || box == percentBaseEditor || box == percentLevelEditor || box == percentUpperEditor)
                && (key == WpfInput.Key.OemPeriod || key == WpfInput.Key.OemComma
                || key == WpfInput.Key.Decimal || key == WpfInput.Key.Separator))
                InsertOffsetText(box, CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator == "," ? "," : ".");
        }

        private CheckBox CreateCheckBox(string text, bool initial, Action<bool> setter)
        {
            CheckBox c = new CheckBox { Content = text, IsChecked = initial, Foreground = WpfBrushes.White,
                VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 9, 0) };
            c.Checked += (s,e) => { if (!syncingTemplatePanel && !templateLoading) { setter(true); Repaint(); } };
            c.Unchecked += (s,e) => { if (!syncingTemplatePanel && !templateLoading) { setter(false); Repaint(); } };
            return c;
        }

        private Button NewButton(string text, Action action)
        {
            Button b = new Button { Content = text, Margin = new Thickness(1), Padding = new Thickness(4, 1, 4, 1),
                Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(46, 51, 62)),
                Foreground = WpfBrushes.White, FontSize = PanelTextSize, MinHeight = Math.Max(24, PanelTextSize + 11) };
            b.Click += (s,e) => { if (!templateLoading) action(); };
            return b;
        }

        private void UninstallUserInterface()
        {
            if (ChartControl != null) ChartControl.SizeChanged -= ToolbarChart_SizeChanged;
            if (offsetInputManager != null)
            {
                offsetInputManager.PreProcessInput -= OffsetInput_PreProcessInput;
                offsetInputManager = null;
            }
            offsetModeSelector = null;
            templateStatusLabel = null;
            anchorStudyStatusLabel = null;
            anchorStudyApplyButton = null;
            anchorStudyResult = null;
            anchorStudyRunning = false;
            atrPeriodEditor = null;
            commitAtrPeriodEditor = null;
            restoreAtrPeriodEditor = null;
            toleranceEditor = null;
            commitToleranceEditor = null;
            restoreToleranceEditor = null;
            offsetEditor = null;
            percentBaseEditor = percentLevelEditor = percentUpperEditor = null;
            commitPercentEditors = restorePercentEditors = null;
            chkPercentBands = null;
            commitOffsetEditor = null;
            restoreOffsetEditor = null;
            if (toolbar != null)
            {
                if (UserControlCollection.Contains(toolbar)) UserControlCollection.Remove(toolbar);
                toolbar.Children.Clear();
                toolbar = null;
            }
        }

        private void Repaint()
        {
            if (ChartControl != null && State != State.Terminated) ForceRefresh();
        }

        private int LastLoaded { get { return Bars == null ? -1 : Bars.Count - 1; } }


        private void SetAnchorStudyStatus(string message, bool canApply)
        {
            ChartControl cc = ChartControl;
            if (cc == null || State == State.Terminated) return;
            cc.Dispatcher.InvokeAsync(() =>
            {
                if (anchorStudyStatusLabel != null) anchorStudyStatusLabel.Text = message;
                if (anchorStudyApplyButton != null) anchorStudyApplyButton.IsEnabled = canApply;
            });
        }

        private void RunAnchorStudy()
        {
            if (anchorStudyRunning || templateLoading) return;
            anchorStudyRunning = true;
            anchorStudyResult = null;
            if (anchorStudyApplyButton != null) anchorStudyApplyButton.IsEnabled = false;
            if (anchorStudyStatusLabel != null)
                anchorStudyStatusLabel.Text = "Estudiando OHLC cargado · sin modificar el ancla...";
            try { TriggerCustomEvent(o => ComputeAnchorStudy(), null); }
            catch (Exception ex)
            {
                anchorStudyRunning = false;
                SetAnchorStudyStatus("Estudio no iniciado: " + ex.GetBaseException().Message, false);
            }
        }

        // Calidad retrospectiva de giro: cercania del MINIMO de señal 1 al minimo
        // local y del MAXIMO de señal 2 al maximo local, con ventana +-3 velas.
        // El estudio puede examinar barras posteriores para EVALUAR el pasado,
        // pero ninguna señal viva del indicador utiliza estas puntuaciones.
        // Los candidatos se seleccionan en dos tramos iniciales independientes;
        // el ultimo 30% queda exclusivamente para validacion fuera de muestra.
        private void ComputeAnchorStudy()
        {
            try
            {
                if (State == State.Terminated || Bars == null || lastClosedIndex < 600)
                {
                    SetAnchorStudyStatus("Estudio: se necesitan al menos 600 velas cerradas.", false);
                    return;
                }
                int last = Math.Min(lastClosedIndex, LastLoaded);
                const int radius = 3;
                int first = radius + 1, end = last - radius;
                int count = end - first + 1;
                if (count < 590)
                {
                    SetAnchorStudyStatus("Estudio: historico cerrado insuficiente.", false);
                    return;
                }
                int c1 = first + (int)(count * 0.35);
                int c2 = first + (int)(count * 0.70);
                double[] highs = new double[last + 1], lows = new double[last + 1];
                double[] bull = new double[last + 1], bear = new double[last + 1];
                for (int i = 0; i <= last; i++)
                {
                    highs[i] = Bars.GetHigh(i);
                    lows[i] = Bars.GetLow(i);
                }
                double[] baseline = new double[3], baselineCount = new double[3];
                for (int i = first; i <= end; i++)
                {
                    // Separar estrictamente las ventanas: una vela de
                    // entrenamiento no debe mirar tres velas de validacion.
                    if (Math.Abs(i - c1) <= radius || Math.Abs(i - c2) <= radius) continue;
                    double lo = double.PositiveInfinity, hi = double.NegativeInfinity;
                    for (int j = i - radius; j <= i + radius; j++)
                    {
                        if (lows[j] < lo) lo = lows[j];
                        if (highs[j] > hi) hi = highs[j];
                    }
                    double range = hi - lo;
                    if (range <= 0 || double.IsNaN(range) || double.IsInfinity(range))
                        bull[i] = bear[i] = 0.5;
                    else
                    {
                        bull[i] = Math.Max(0, Math.Min(1, (hi - lows[i]) / range));
                        bear[i] = Math.Max(0, Math.Min(1, (highs[i] - lo) / range));
                    }
                    int segment = i < c1 ? 0 : i < c2 ? 1 : 2;
                    baseline[segment] += 0.5 * (bull[i] + bear[i]);
                    baselineCount[segment]++;
                }
                for (int i = 0; i < 3; i++) baseline[i] /= Math.Max(1, baselineCount[i]);

                int minSpan = Math.Max(2, Math.Min(300, StudyMinBars));
                int maxSpan = Math.Max(2, Math.Min(300, StudyMaxBars));
                if (minSpan > maxSpan)
                {
                    SetAnchorStudyStatus("Estudio: el mínimo de barras supera el máximo.", false);
                    return;
                }
                double bestRank = double.NegativeInfinity;
                AnchorStudyResult best = null;
                // El intervalo mantiene la definicion EXACTA del ancla manual.
                // Rango configurable; solo se usa el OHLC ya cargado en el chart.
                for (int span = minSpan; span <= maxSpan; span++)
                {
                    int period = 2 * span;
                    double[] up = new double[3 * period], dn = new double[3 * period];
                    int[] ns = new int[3 * period];
                    for (int i = first; i <= end; i++)
                    {
                        if (Math.Abs(i - c1) <= radius || Math.Abs(i - c2) <= radius) continue;
                        int segment = i < c1 ? 0 : i < c2 ? 1 : 2;
                        int slot = segment * period + i % period;
                        up[slot] += bull[i];
                        dn[slot] += bear[i];
                        ns[slot]++;
                    }
                    for (int phase = 0; phase < period; phase++)
                    {
                        int opposite = (phase + span) % period;
                        double[] scores = new double[3];
                        int[] samples = new int[3];
                        bool enough = true;
                        for (int segment = 0; segment < 3; segment++)
                        {
                            int a = segment * period + phase, b = segment * period + opposite;
                            samples[segment] = ns[a] + ns[b];
                            if (ns[a] < 10 || ns[b] < 10 || samples[segment] < 25)
                            {
                                enough = false;
                                break;
                            }
                            scores[segment] = (up[a] + dn[b]) / samples[segment];
                        }
                        if (!enough) continue;
                        // Preferencia por parametros que funcionen en AMBAS mitades de
                        // entrenamiento. Penalizar tambien su discrepancia interna.
                        double e0 = scores[0] - baseline[0];
                        double e1 = scores[1] - baseline[1];
                        double stability = Math.Min(e0, e1) - 0.25 * Math.Abs(e0 - e1);
                        // Penalizar muestras reducidas para no favorecer intervalos enormes.
                        double rank = stability - 0.005 * Math.Sqrt(100.0 / Math.Min(samples[0], samples[1]));
                        if (rank > bestRank)
                        {
                            bestRank = rank;
                            best = new AnchorStudyResult {
                                Interval = span, Phase = phase, Bars = count,
                                TrainQuality = (scores[0]*samples[0] + scores[1]*samples[1])/(samples[0]+samples[1]),
                                ValidationQuality = scores[2],
                                TrainBaseline = (baseline[0]*samples[0]+baseline[1]*samples[1])/(samples[0]+samples[1]),
                                ValidationBaseline = baseline[2],
                                SampleFirst = samples[0], SampleSecond = samples[1],
                                SampleValidation = samples[2], LastBarTime = Bars.GetTime(last)
                            };
                        }
                    }
                }
                anchorStudyResult = best;
                if (best == null)
                {
                    SetAnchorStudyStatus("Estudio: no hay suficientes ciclos para recomendar un intervalo estable.", false);
                    return;
                }
                double edgeTrain = 100.0 * (best.TrainQuality - best.TrainBaseline);
                double edgeValid = 100.0 * (best.ValidationQuality - best.ValidationBaseline);
                // Menos de 1 punto porcentual fuera de muestra es demasiado
                // pequeño para declarar estabilidad tras probar muchos desfases.
                bool stable = edgeTrain > 1.0 && edgeValid > 1.0;
                string message = "Estudio: " + best.Interval + " barras | fase " + best.Phase
                    + " | ventaja histórica " + edgeTrain.ToString("+0.0;-0.0;0.0", CultureInfo.CurrentCulture)
                    + " pp | validación " + edgeValid.ToString("+0.0;-0.0;0.0", CultureInfo.CurrentCulture)
                    + " pp" + (stable ? " · estable" : " · débil/inestable, solo experimental");
                SetAnchorStudyStatus(message, true);
            }
            catch (Exception ex)
            {
                anchorStudyResult = null;
                SetAnchorStudyStatus("Error en estudio: " + ex.GetBaseException().Message, false);
            }
            finally { anchorStudyRunning = false; }
        }

        private void ApplyAnchorStudy()
        {
            if (anchorStudyRunning || templateLoading || anchorStudyResult == null) return;
            if (anchorStudyStatusLabel != null) anchorStudyStatusLabel.Text = "Aplicando intervalo estudiado...";
            try { TriggerCustomEvent(o => ApplyAnchorStudyOnBarThread(), null); }
            catch (Exception ex) { SetAnchorStudyStatus("No se pudo aplicar: " + ex.GetBaseException().Message, true); }
        }

        private void ApplyAnchorStudyOnBarThread()
        {
            AnchorStudyResult result = anchorStudyResult;
            if (result == null || State == State.Terminated || Bars == null) return;
            int last = Math.Min(lastClosedIndex, LastLoaded);
            if (last < result.Interval + 2 || Bars.GetTime(last) != result.LastBarTime)
            {
                SetAnchorStudyStatus("El gráfico ha cambiado: vuelve a ejecutar Estudiar ancla.", false);
                anchorStudyResult = null;
                return;
            }
            if (nativeAnchorPending || nativeDragActive || templateLoading)
            {
                SetAnchorStudyStatus("Termina de mover el ancla antes de aplicar el estudio.", true);
                return;
            }
            int span = result.Interval, period = 2 * span;
            int a = result.Phase + (int)Math.Floor((last-span-result.Phase)/(double)period)*period;
            int b = a + span;
            if (a < 0 || b > last)
            {
                SetAnchorStudyStatus("No se pudo situar la fase calculada en el histórico.", true);
                return;
            }
            lock (anchorGate)
            {
                // Se cambia SOLO al aceptar. La misma fase se proyecta hacia
                // atras y hacia delante en separaciones perfectamente uniformes.
                anchorIndexA = a;
                anchorIndexB = b;
                anchorPriceA = Bars.GetClose(a);
                anchorPriceB = Bars.GetClose(b);
                BaseBinary = 1; // El mejor desfase ya incluye ambos sentidos 1/2.
                anchorsInitialized = true;
                anchorFileInvalid = false;
                anchorStatePath = GetAnchorStatePath();
                movingWholeAnchor = false;
                SaveAnchorState();
                WriteAnchorFile();
                QueueNativeAnchor();
            }
            SetAnchorStudyStatus("Aplicado: " + span + " barras; fase histórica " + result.Phase
                + " · ancla guardada.", false);
            anchorStudyResult = null;
            Repaint();
        }

        private string TemplateFolder()
        {
            string folder = Path.Combine(NinjaTrader.Core.Globals.UserDataDir, "ForcePhaseLab", "Templates");
            Directory.CreateDirectory(folder);
            return folder;
        }

        private string TemplateContext()
        {
            return Instrument.FullName + "|" + BarsPeriod.ToString() + "|" + Bars.TradingHours.Name
                + "|" + (applicationTimeZone == null ? "" : applicationTimeZone.Id);
        }

        private PropertyInfo TemplateProperty(string name)
        {
            PropertyInfo prop = typeof(ForcePhaseLab).GetProperty(name, BindingFlags.Public | BindingFlags.Instance);
            if (prop == null || !prop.CanRead || !prop.CanWrite)
                throw new InvalidDataException("Parámetro no disponible: " + name);
            return prop;
        }

        private void ReportTemplate(string message)
        {
            if (templateStatusLabel != null) templateStatusLabel.Text = message;
        }

        private void SaveFullTemplate()
        {
            if (templateLoading) return;
            string temp = null;
            try
            {
                if (commitOffsetEditor != null) commitOffsetEditor();
                if (commitToleranceEditor != null) commitToleranceEditor();
                if (commitPercentEditors != null) commitPercentEditors();
                EnsureAnchors();
                ReadNativeAnchor();
                if (!anchorsInitialized || nativeAnchorPending || nativeDragActive)
                    throw new InvalidOperationException("Espera a que el ancla esté disponible y termina de editarla.");
                var dialog = new Microsoft.Win32.SaveFileDialog {
                    Title = "Guardar template ForcePhaseLab", InitialDirectory = TemplateFolder(),
                    Filter = "Template ForcePhaseLab (*.xml)|*.xml", DefaultExt = ".xml",
                    AddExtension = true, OverwritePrompt = true, FileName = "ForcePhaseLab.xml" };
                if (dialog.ShowDialog() != true) return;
                temp = dialog.FileName + "." + Guid.NewGuid().ToString("N") + ".tmp";
                lock (anchorGate)
                {
                    SaveAnchorState();
                    WriteAnchorFile();
                    using (XmlWriter writer = XmlWriter.Create(temp, new XmlWriterSettings { Indent = true, Encoding = Encoding.UTF8 }))
                    {
                        writer.WriteStartDocument();
                        writer.WriteStartElement("ForcePhaseLabTemplate");
                        writer.WriteAttributeString("schema", "1");
                        writer.WriteAttributeString("context", TemplateContext());
                        foreach (string field in TemplateFields)
                        {
                            PropertyInfo prop = TemplateProperty(field);
                            object value = prop.GetValue(this, null);
                            string data = TypeDescriptor.GetConverter(prop.PropertyType).ConvertToInvariantString(value);
                            writer.WriteElementString(field, data ?? string.Empty);
                        }
                        writer.WriteEndElement();
                        writer.WriteEndDocument();
                    }
                }
                if (File.Exists(dialog.FileName)) File.Replace(temp, dialog.FileName, null);
                else File.Move(temp, dialog.FileName);
                ReportTemplate("Template guardado: " + Path.GetFileName(dialog.FileName));
            }
            catch (Exception ex) { ReportTemplate("No se pudo guardar: " + ex.GetBaseException().Message); }
            finally { try { if (temp != null && File.Exists(temp)) File.Delete(temp); } catch { } }
        }

        private Dictionary<string, object> ParseFullTemplate(string path)
        {
            var doc = new XmlDocument { XmlResolver = null };
            using (XmlReader reader = XmlReader.Create(path, new XmlReaderSettings {
                DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null, MaxCharactersInDocument = 1000000 }))
                doc.Load(reader);
            XmlElement root = doc.DocumentElement;
            if (root == null || root.Name != "ForcePhaseLabTemplate" || root.GetAttribute("schema") != "1")
                throw new InvalidDataException("No es un template ForcePhaseLab compatible.");
            if (root.GetAttribute("context") != TemplateContext())
                throw new InvalidDataException("El instrumento, periodo, sesión o zona horaria no coinciden con el template.");
            var values = new Dictionary<string, object>(StringComparer.Ordinal);
            foreach (string field in TemplateFields)
            {
                XmlNodeList nodes = root.SelectNodes(field);
                // Plantillas de versiones anteriores: conservar los ajustes actuales que todavía no existían.
                if ((nodes == null || nodes.Count == 0) && (field == "StudyMinBars" || field == "StudyMaxBars"
                    || field == "HighlightAnchorCycle"
                    || field == "AnchorCycleOpacity" || field == "AnchorCycleBrushSerialize"
                    || field == "TrendFilterMode" || field == "SlopeLookback"
                    || field == "SlopeThresholdAtr" || field == "SlopeAtrPeriod"
                    || field == "AverageLineWidth" || field == "PanelPlacement" || field == "PanelTextSize"
                    || field == "SlopeUpBrushSerialize" || field == "SlopeDownBrushSerialize"
                    || field == "SlopeFlatBrushSerialize"
                    || field == "ShowPercentBands" || field == "PercentBaseRange"
                    || field == "PercentTestLevel" || field == "PercentBandWidth"
                    || field == "PercentBandBrushSerialize" || field == "PercentZoneUpperLevel"
                    || field == "PercentBandStyle" || field == "PercentZoneBrushSerialize"
                    || field == "PercentZoneOpacity")) continue;
                if (nodes == null || nodes.Count != 1) throw new InvalidDataException("Falta o se repite: " + field);
                PropertyInfo prop = TemplateProperty(field);
                object parsed = TypeDescriptor.GetConverter(prop.PropertyType).ConvertFromInvariantString(nodes[0].InnerText);
                if (parsed == null || (parsed is double && (double.IsNaN((double)parsed) || double.IsInfinity((double)parsed)))
                    || (prop.PropertyType.IsEnum && !Enum.IsDefined(prop.PropertyType, parsed)))
                    throw new InvalidDataException("Valor no válido: " + field);
                foreach (object attr in prop.GetCustomAttributes(typeof(RangeAttribute), true))
                    if (!((RangeAttribute)attr).IsValid(parsed)) throw new InvalidDataException("Valor fuera de rango: " + field);
                if (field.EndsWith("BrushSerialize", StringComparison.Ordinal))
                {
                    // Deserializar y congelar el WPF Brush en el hilo de interfaz.
                    // No acceder a recursos WPF mutables desde el hilo NinjaScript.
                    WpfBrush brush = Serialize.StringToBrush((string)parsed);
                    if (brush == null || !brush.CanFreeze) throw new InvalidDataException("Color no válido: " + field);
                    brush = brush.CloneCurrentValue();
                    brush.Freeze();
                    values.Add(field.Substring(0, field.Length - "Serialize".Length), brush);
                }
                else values.Add(field, parsed);
            }
            return values;
        }

        private void LoadFullTemplate()
        {
            if (templateLoading) return;
            try
            {
                var dialog = new Microsoft.Win32.OpenFileDialog {
                    Title = "Cargar template ForcePhaseLab", InitialDirectory = TemplateFolder(),
                    Filter = "Template ForcePhaseLab (*.xml)|*.xml", CheckFileExists = true, Multiselect = false };
                if (dialog.ShowDialog() != true) return;
                Dictionary<string, object> values = ParseFullTemplate(dialog.FileName);
                int ai = FindExactSavedIndex((string)values["AnchorStartStamp"]);
                int bi = FindExactSavedIndex((string)values["AnchorEndStamp"]);
                if (ai < 0 || bi < 0 || bi-ai != (int)values["SeparationBars"])
                    throw new InvalidDataException("Faltan barras del ancla o cambió su intervalo. Carga el histórico original.");
                if (nativeAnchorPending || nativeDragActive)
                    throw new InvalidOperationException("Termina primero de editar el ancla.");
                string fileName = Path.GetFileName(dialog.FileName);
                templateLoading = true;
                if (toolbar != null) toolbar.IsEnabled = false;
                ReportTemplate("Cargando template: " + fileName);
                // El cambio de media y la reposición de la serie de plot necesitan el
                // contexto NinjaScript sincronizado, no el hilo Dispatcher del panel.
                TriggerCustomEvent(o => ApplyFullTemplate(values, fileName), null);
            }
            catch (Exception ex)
            {
                templateLoading = false;
                if (toolbar != null) toolbar.IsEnabled = true;
                ReportTemplate("No se pudo cargar: " + ex.GetBaseException().Message);
            }
        }

        private void ApplyFullTemplate(Dictionary<string, object> values, string fileName)
        {
            string result;
            try
            {
                if (State == State.Terminated) return;
                int ai = FindExactSavedIndex((string)values["AnchorStartStamp"]);
                int bi = FindExactSavedIndex((string)values["AnchorEndStamp"]);
                if (ai < 0 || bi < 0 || bi-ai != (int)values["SeparationBars"])
                    throw new InvalidDataException("El histórico del ancla ha cambiado.");
                var type = (PhaseTestAverageType)values["AverageType"];
                int period = (int)values["AveragePeriod"];
                Indicator newAverage = activeAverage;
                if (newAverage == null || type != AverageType || period != AveragePeriod)
                    newAverage = CreateNativeAverage(type, period);
                if (newAverage == null) throw new InvalidOperationException("No se ha podido inicializar la media.");
                int slopePeriod = values.ContainsKey("SlopeAtrPeriod") ? (int)values["SlopeAtrPeriod"] : SlopeAtrPeriod;
                ATR newSlopeAtr = slopeAtr;
                if (newSlopeAtr == null || slopePeriod != SlopeAtrPeriod)
                    newSlopeAtr = ATR(slopePeriod);
                int end = Math.Min(lastClosedIndex, CurrentBar);
                if (end >= 0)
                {
                    newAverage.Update(end, 0);
                    newSlopeAtr.Update(end, 0);
                }
                // Leer primero toda la serie; si falla la nueva media, no cambiar geometría ni filtros.
                var maValues = new double[Math.Max(0, end + 1)];
                for (int i = 1; i <= end; i++) maValues[i] = newAverage.Values[0].GetValueAt(i);
                lock (anchorGate)
                {
                    foreach (KeyValuePair<string, object> entry in values)
                        TemplateProperty(entry.Key).SetValue(this, entry.Value, null);
                    activeAverage = newAverage;
                    slopeAtr = newSlopeAtr;
                    // Compatibilidad: plantillas anteriores solo contenian un nivel.
                    // Preservar ese nivel como limite interior y construir un exterior valido.
                    if (PercentTestLevel >= PercentZoneUpperLevel)
                    {
                        if (PercentTestLevel >= 500.0) PercentTestLevel = 475.0;
                        PercentZoneUpperLevel = Math.Min(500.0, PercentTestLevel + 25.0);
                    }
                    // El template puede modificar el grosor sin reinicializar el indicador.
                    Plots[0].Width = AverageLineWidth;
                    trendStateCache.Clear(); cachedToleranceTicks = -1;
                    slopeStateCache.Clear(); cachedSlopeLookback = -1; cachedSlopeAtrPeriod = -1;
                    cachedSlopeThreshold = double.NaN;
                    markerAtrCache.Clear(); cachedMarkerAtrPeriod = -1;
                    anchorIndexA = ai; anchorIndexB = bi;
                    anchorPriceA = AnchorStartPrice; anchorPriceB = AnchorEndPrice;
                    anchorsInitialized = true;
                    anchorRestoreAttempted = true;
                    anchorFileInvalid = false;
                    anchorStatePath = GetAnchorStatePath();
                    movingWholeAnchor = false; nativeDragActive = false;
                    SaveAnchorState();
                    WriteAnchorFile();
                    QueueNativeAnchor();
                }
                for (int i = 1; i <= end; i++)
                {
                    int ago = CurrentBar - i;
                    Values[0][ago] = ShowAverage ? maValues[i] : double.NaN;
                    PlotBrushes[0][ago] = SlopeBrushFor(SlopeTrendAt(i));
                }
                result = "Template cargado: " + fileName + (anchorDirty ? " · no se pudo persistir el ancla" : "");
            }
            catch (Exception ex) { result = "Error al cargar: " + ex.GetBaseException().Message; }
            finally { templateLoading = false; }
            if (ChartControl != null && State != State.Terminated)
                ChartControl.Dispatcher.InvokeAsync(() => {
                    SyncTemplatePanel();
                    if (toolbar != null) toolbar.IsEnabled = true;
                    ReportTemplate(result);
                    Repaint();
                });
        }

        private void SyncTemplatePanel()
        {
            syncingTemplatePanel = true;
            try
            {
                if (chkA != null) chkA.IsChecked = ShowA;
                if (chkB != null) chkB.IsChecked = ShowB;
                if (chkWith != null) chkWith.IsChecked = ShowWithTrend;
                if (chkAgainst != null) chkAgainst.IsChecked = ShowAgainstTrend;
                if (chkPercentBands != null) chkPercentBands.IsChecked = ShowPercentBands;
                if (restorePercentEditors != null) restorePercentEditors();
                if (offsetModeSelector != null) offsetModeSelector.SelectedIndex = UseAtrMarkerOffset ? 1 : 0;
                if (restoreOffsetEditor != null) restoreOffsetEditor();
                if (restoreAtrPeriodEditor != null) restoreAtrPeriodEditor();
                if (restoreToleranceEditor != null) restoreToleranceEditor();
                if (toolbar != null)
                {
                    toolbar.Visibility = ShowToolbar ? System.Windows.Visibility.Visible : System.Windows.Visibility.Collapsed;
                    ApplyToolbarAppearance();
                }
            }
            finally { syncingTemplatePanel = false; }
        }

        private string GetAnchorStatePath()
        {
            string key = Instrument.FullName + "|" + BarsPeriod.ToString()
                + "|" + Bars.TradingHours.Name + "|" + (applicationTimeZone == null ? "" : applicationTimeZone.Id)
                + "|" + (string.IsNullOrWhiteSpace(AnchorProfile) ? "Principal" : AnchorProfile.Trim());
            using (SHA256 hash = SHA256.Create())
            {
                string id = BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(key))).Replace("-", "");
                return Path.Combine(NinjaTrader.Core.Globals.UserDataDir, "ForcePhaseLab", "Anchors", id + ".txt");
            }
        }

        private static bool ParseStamp(string stamp, out DateTime t)
        {
            return DateTime.TryParseExact(stamp, "o", CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out t);
        }

        private int FindExactSavedIndex(string stamp)
        {
            DateTime t;
            if (!ParseStamp(stamp, out t) || LastLoaded < 0) return -1;
            if (t < Bars.GetTime(0) || t > Bars.GetTime(LastLoaded)) return -1;
            int i = Bars.GetBar(t);
            return i >= 0 && i <= LastLoaded && Bars.GetTime(i).Ticks == t.Ticks ? i : -1;
        }

        private void ReadAnchorFile()
        {
            if (anchorRestoreAttempted) return;
            anchorRestoreAttempted = true;
            try
            {
                anchorStatePath = GetAnchorStatePath();
                lock (anchorFileGate)
                {
                    if (!File.Exists(anchorStatePath)) return;
                    string[] f = File.ReadAllLines(anchorStatePath);
                    DateTime ta, tb; double pa, pb; int span, binary;
                    if (f.Length != 7 || f[0] != "ForcePhaseLab.Anchor.1"
                        || !ParseStamp(f[1], out ta) || !ParseStamp(f[2], out tb) || ta >= tb
                        || !double.TryParse(f[3], NumberStyles.Float, CultureInfo.InvariantCulture, out pa)
                        || !double.TryParse(f[4], NumberStyles.Float, CultureInfo.InvariantCulture, out pb)
                        || double.IsNaN(pa) || double.IsInfinity(pa) || double.IsNaN(pb) || double.IsInfinity(pb)
                        || !int.TryParse(f[5], NumberStyles.Integer, CultureInfo.InvariantCulture, out span) || span < 2 || span > 300
                        || !int.TryParse(f[6], NumberStyles.Integer, CultureInfo.InvariantCulture, out binary) || (binary != 1 && binary != 2))
                    {
                        anchorFileInvalid = true;
                        anchorStatus = "Archivo de ancla no valido · no se sobrescribe";
                        return;
                    }
                    AnchorStartStamp = f[1]; AnchorEndStamp = f[2];
                    AnchorStartPrice = pa; AnchorEndPrice = pb;
                    SeparationBars = span; BaseBinary = binary;
                }
            }
            catch (Exception ex)
            {
                anchorFileInvalid = true;
                anchorStatus = "No se pudo leer el ancla · " + ex.GetType().Name;
            }
        }

        private void EnsureAnchors()
        {
            int last = LastLoaded;
            if (anchorsInitialized || last < 5) return;
            lock (anchorGate)
            {
                if (anchorsInitialized) return;
                ReadAnchorFile();
                if (anchorFileInvalid) return;
                bool hasSaved = !string.IsNullOrEmpty(AnchorStartStamp) || !string.IsNullOrEmpty(AnchorEndStamp);
                int ai, bi;
                if (hasSaved)
                {
                    ai = FindExactSavedIndex(AnchorStartStamp);
                    bi = FindExactSavedIndex(AnchorEndStamp);
                    // Nunca sustituir silenciosamente una fecha por la barra mas cercana.
                    // Si faltan datos, conservar el archivo y esperar a que se carguen.
                    if (ai < 0 || bi < 0 || bi-ai != SeparationBars)
                    {
                        anchorStatus = "Ancla guardada fuera del historico o intervalo distinto · cargar datos originales";
                        return;
                    }
                    anchorPriceA = AnchorStartPrice;
                    anchorPriceB = AnchorEndPrice;
                }
                else
                {
                    ai = AnchorAIndex >= 0 ? AnchorAIndex : Math.Max(0, last - 4 * SeparationBars);
                    bi = AnchorBIndex >= 0 ? AnchorBIndex : ai + SeparationBars;
                    int span = Math.Max(2, Math.Min(last, Math.Min(300, bi-ai)));
                    ai = Math.Max(0, Math.Min(last-span, ai)); bi = ai+span;
                    anchorPriceA = Bars.GetClose(ai); anchorPriceB = Bars.GetClose(bi);
                }
                anchorIndexA = ai; anchorIndexB = bi;
                anchorsInitialized = true;
                SaveAnchorState();
                WriteAnchorFile();
            }
        }

        private void SaveAnchorState()
        {
            AnchorAIndex = anchorIndexA;
            AnchorBIndex = anchorIndexB;
            SeparationBars = anchorIndexB - anchorIndexA;
            AnchorStartStamp = Bars.GetTime(anchorIndexA).ToString("o", CultureInfo.InvariantCulture);
            AnchorEndStamp = Bars.GetTime(anchorIndexB).ToString("o", CultureInfo.InvariantCulture);
            AnchorStartPrice = anchorPriceA;
            AnchorEndPrice = anchorPriceB;
            anchorDirty = true;
        }

        private void WriteAnchorFile()
        {
            if (!anchorDirty || anchorFileInvalid || string.IsNullOrEmpty(anchorStatePath)) return;
            string temp = anchorStatePath + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                lock (anchorFileGate)
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(anchorStatePath));
                    File.WriteAllLines(temp, new string[] { "ForcePhaseLab.Anchor.1", AnchorStartStamp, AnchorEndStamp,
                        AnchorStartPrice.ToString("R", CultureInfo.InvariantCulture), AnchorEndPrice.ToString("R", CultureInfo.InvariantCulture),
                        SeparationBars.ToString(CultureInfo.InvariantCulture), BaseBinary.ToString(CultureInfo.InvariantCulture) });
                    if (File.Exists(anchorStatePath)) File.Replace(temp, anchorStatePath, null);
                    else File.Move(temp, anchorStatePath);
                }
                anchorDirty = false;
                anchorStatus = "Ancla guardada";
            }
            catch (Exception ex) { anchorStatus = "No se pudo guardar el ancla · " + ex.GetType().Name; }
            finally { try { if (File.Exists(temp)) File.Delete(temp); } catch { } }
        }

        // Se crea una sola vez. No llamar Draw.Line en cada tick o render,
        // pues sobrescribiria los cambios del usuario mientras arrastra.
        private void QueueNativeAnchor()
        {
            if (!anchorsInitialized || nativeAnchorPending || State == State.Terminated) return;
            nativeAnchorPending = true;
            TriggerCustomEvent(o =>
            {
                try
                {
                    if (State == State.Terminated) return;
                    lock (anchorGate)
                    {
                        nativeAnchor = NativeDraw.Line(this, NativeAnchorTag, false,
                            Bars.GetTime(anchorIndexA), anchorPriceA,
                            Bars.GetTime(anchorIndexB), anchorPriceB,
                            WpfBrushes.Gold, NinjaTrader.Gui.DashStyleHelper.Solid, 2);
                        if (nativeAnchor != null) nativeAnchor.IsLocked = false;
                    }
                }
                finally
                {
                    nativeAnchorPending = false;
                    if (ChartControl != null)
                        ChartControl.Dispatcher.InvokeAsync(() => Repaint());
                }
            }, null);
        }

        // El objeto nativo realiza el hit-test, seleccion, captura, drag y edicion
        // de los extremos. El indicador lee sus tiempos y reconstruye ambas grids.
        private void ReadNativeAnchor()
        {
            if (nativeAnchor == null || nativeAnchorPending || templateLoading) return;
            lock (anchorGate)
            {
                int last = LastLoaded;
                if (last < 2) return;
                int rawA = Bars.GetBar(nativeAnchor.StartAnchor.Time);
                int rawB = Bars.GetBar(nativeAnchor.EndAnchor.Time);
                string dragState = nativeAnchor.DrawingState.ToString();
                bool moving = dragState == "Moving";
                bool editing = dragState == "Editing";
                bool releasedWhole = movingWholeAnchor && !moving;
                if (moving && !movingWholeAnchor)
                {
                    wholeAnchorSpan = anchorIndexB - anchorIndexA;
                    movingWholeAnchor = true;
                }
                int ai, bi;
                if (moving || releasedWhole)
                {
                    int span = Math.Max(2, Math.Min(last, wholeAnchorSpan));
                    ai = Math.Max(0, Math.Min(last-span, rawA));
                    bi = ai + span;
                }
                else
                {
                    // Los extremos editan el intervalo; no invertir el ancla
                    // ni permitir un intervalo cero al cruzar los extremos.
                    ai = Math.Max(0, Math.Min(last-2, rawA));
                    bi = Math.Max(2, Math.Min(last, rawB));
                    if (bi-ai < 2 || bi-ai > 300)
                    {
                        if (rawA != anchorIndexA && rawB == anchorIndexB)
                            ai = Math.Max(0, Math.Min(bi-2, Math.Max(bi-300, ai)));
                        else
                            bi = Math.Max(ai+2, Math.Min(last, Math.Min(ai+300, bi)));
                    }
                }
                double ya = nativeAnchor.StartAnchor.Price;
                double yb = nativeAnchor.EndAnchor.Price;
                if (ai != anchorIndexA || bi != anchorIndexB || ya != anchorPriceA || yb != anchorPriceB)
                {
                    anchorIndexA = ai; anchorIndexB = bi;
                    anchorPriceA = ya; anchorPriceB = yb;
                    SaveAnchorState();
                }
                movingWholeAnchor = moving;
                // Guardar una sola vez al terminar el arrastre (tambien edicion de extremo).
                if (!moving && !editing && (nativeDragActive || anchorDirty)) WriteAnchorFile();
                nativeDragActive = moving || editing;
                // No escribir sobre el objeto durante el drag. Al soltar,
                // ajustarlo al intervalo exacto si el movimiento nativo difiere.
                if (!moving && !editing && (ai != rawA || bi != rawB))
                    QueueNativeAnchor();
            }
        }

        private void PersistAnchors()
        {
            SaveAnchorState();
            WriteAnchorFile();
            QueueNativeAnchor();
            Repaint();
        }

        private void PlaceVisibleAnchor()
        {
            EnsureAnchors();
            if (!anchorsInitialized || ChartBars == null) { Repaint(); return; }
            ReadNativeAnchor();
            lock (anchorGate)
            {
                int last = LastLoaded;
                int right = Math.Max(2, Math.Min(last, ChartBars.ToIndex));
                int left = Math.Max(0, Math.Min(right-2, ChartBars.FromIndex));
                int span = anchorIndexB-anchorIndexA;
                // Seleccionar un par YA EXISTENTE de la reticula en la vista.
                // k puede ser negativo. Si k es impar, adaptar la polaridad de origen
                // para conservar la binaria de TODAS las barras, pasadas y futuras.
                int target = Math.Min(last-span, left + (right-left)/3);
                int minK = (int)Math.Ceiling(-anchorIndexA/(double)span);
                int maxK = (int)Math.Floor((last-span-anchorIndexA)/(double)span);
                int viewMinK = (int)Math.Ceiling((left-anchorIndexA)/(double)span);
                int viewMaxK = (int)Math.Floor((right-span-anchorIndexA)/(double)span);
                int lo = Math.Max(minK, viewMinK), hi = Math.Min(maxK, viewMaxK);
                if (lo > hi) { lo = minK; hi = maxK; }
                if (lo > hi) return;
                int k = Math.Max(lo, Math.Min(hi, (int)Math.Round((target-anchorIndexA)/(double)span, MidpointRounding.AwayFromZero)));
                if (k % 2 != 0) BaseBinary = 3-BaseBinary;
                anchorIndexA += k*span;
                anchorIndexB = anchorIndexA + span;
                // Precios de la guia sobre las velas actuales; los dots mantienen
                // exactamente sus propios precios, offset y colores originales.
                anchorPriceA = Bars.GetClose(anchorIndexA);
                anchorPriceB = Bars.GetClose(anchorIndexB);
                PersistAnchors();
            }
        }

        private void MoveOrigin(int d)
        {
            EnsureAnchors(); if (!anchorsInitialized) return;
            ReadNativeAnchor();
            lock (anchorGate)
            {
                anchorIndexA = Math.Max(Math.Max(0, anchorIndexB-300), Math.Min(anchorIndexB - 2, anchorIndexA + d));
                PersistAnchors();
            }
        }
        private void MoveBoth(int d)
        {
            EnsureAnchors(); if (!anchorsInitialized) return;
            ReadNativeAnchor();
            lock (anchorGate)
            {
                int effective = Math.Max(-anchorIndexA, Math.Min(LastLoaded-anchorIndexB, d));
                anchorIndexA += effective; anchorIndexB += effective;
                PersistAnchors();
            }
        }
        private void MoveSecond(int d)
        {
            EnsureAnchors(); if (!anchorsInitialized) return;
            ReadNativeAnchor();
            lock (anchorGate)
            {
                anchorIndexB = Math.Max(anchorIndexA + 2, Math.Min(Math.Min(LastLoaded, anchorIndexA+300), anchorIndexB + d));
                PersistAnchors();
            }
        }

        private DateTime AppToUtc(DateTime value)
        {
            return TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(value, DateTimeKind.Unspecified),
                applicationTimeZone ?? TimeZoneInfo.Local);
        }
        private DateTime UtcToApp(DateTime value)
        {
            return TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(value, DateTimeKind.Utc),
                applicationTimeZone ?? TimeZoneInfo.Local);
        }

        // Eje temporal: reconstruccion de cierres programados por Trading Hours.
        // Eje equidistante: slots de barra, no diferencia entre dos X offscreen.
        private DateTime ProjectFutureTime(int idx)
        {
            int last = LastLoaded;
            if (last < 0 || idx <= last || nominalSeconds <= 0) return DateTime.MinValue;
            DateTime baseTime = Bars.GetTime(last);
            if (futureCacheBase != last || futureCacheBaseTime != baseTime)
            {
                futureTimes.Clear(); futureCacheBase = last; futureCacheBaseTime = baseTime;
                futureTimes.Add(baseTime);
            }
            int offset = idx-last;
            if (offset > 10000) return DateTime.MinValue;
            try
            {
                DateTime begin = DateTime.MinValue, end = DateTime.MinValue;
                while (futureTimes.Count <= offset)
                {
                    DateTime cursor = AppToUtc(futureTimes[futureTimes.Count-1]);
                    DateTime probe = cursor.AddTicks(1);
                    if (probe > end || probe < begin)
                    {
                        SessionIterator it = new SessionIterator(Bars);
                        if (!it.GetNextSession(UtcToApp(probe), false)) return DateTime.MinValue;
                        begin = AppToUtc(it.ActualSessionBegin);
                        end = AppToUtc(it.ActualSessionEnd);
                    }
                    if (end <= cursor || end <= begin) return DateTime.MinValue;
                    long bt = Math.Max(1L, (long)Math.Round(nominalSeconds*TimeSpan.TicksPerSecond));
                    long elapsed = Math.Max(0L, (probe-begin).Ticks);
                    long n = Math.Max(1L, (elapsed+bt-1L)/bt);
                    DateTime next = begin.AddTicks(n*bt);
                    if (next > end) next = end;
                    if (next <= cursor) return DateTime.MinValue;
                    futureTimes.Add(UtcToApp(next));
                }
                return futureTimes[offset];
            }
            catch { return DateTime.MinValue; }
        }

        private float GetBarX(ChartControl cc, int idx)
        {
            int last = LastLoaded;
            if (idx < 0 || last < 0) return float.NaN;
            if (idx <= last) return cc.GetXByBarIndex(ChartBars, idx);
            if (cc.BarSpacingType == BarSpacingType.TimeBased)
            {
                // Los dibujos muy lejanos quedan fuera del panel.
                if (idx-last > 10000) return float.NaN;
                DateTime t = ProjectFutureTime(idx);
                // No fingir tiempos de barras tick/range en un eje de fechas.
                return t == DateTime.MinValue ? float.NaN : cc.GetXByTime(t);
            }
            int reference = last; // referencia absoluta, independiente del scroll
            float step = cc.Properties.BarDistance;
            if (step <= 0 || float.IsNaN(step) || float.IsInfinity(step)) return float.NaN;
            return cc.GetXByBarIndex(ChartBars, reference) + (idx-reference)*step;
        }

        private double TrendAt(int idx)
        {
            if (idx < AveragePeriod * 2 || idx > lastClosedIndex)
                return double.NaN;
            // La serie de la media se calcula siempre aunque se oculte la linea.
            if (activeAverage == null) return double.NaN;
            return activeAverage.Values[0].GetValueAt(idx);
        }

        // Pendiente de la misma MA sin segunda media ni confirmación futura.
        // Tasa por vela normalizada con ATR; histéresis: entrar al 100 % del umbral,
        // pasar a lateral por debajo del 60 %. Los estados históricos quedan congelados
        // según el cierre de cada barra y son independientes del desplazamiento del gráfico.
        private int SlopeTrendAt(int bar)
        {
            if (slopeAtr == null || activeAverage == null || bar < 0
                || bar > lastClosedIndex || bar > LastLoaded) return 0;
            int lookback = Math.Max(1, SlopeLookback);
            int atrPeriod = Math.Max(1, SlopeAtrPeriod);
            double threshold = Math.Max(0, SlopeThresholdAtr);
            if (cachedSlopeLookback != lookback || cachedSlopeAtrPeriod != atrPeriod
                || cachedSlopeThreshold != threshold)
            {
                slopeStateCache.Clear();
                cachedSlopeLookback = lookback;
                cachedSlopeAtrPeriod = atrPeriod;
                cachedSlopeThreshold = threshold;
            }
            int warmup = Math.Max(AveragePeriod * 2, atrPeriod + lookback);
            while (slopeStateCache.Count <= bar)
            {
                int i = slopeStateCache.Count;
                int previous = i > 0 ? slopeStateCache[i - 1] : 0;
                int state = 0;
                if (i >= warmup)
                {
                    double now = activeAverage.Values[0].GetValueAt(i);
                    double past = activeAverage.Values[0].GetValueAt(i - lookback);
                    double atr = slopeAtr.Values[0].GetValueAt(i);
                    if (!double.IsNaN(now) && !double.IsInfinity(now)
                        && !double.IsNaN(past) && !double.IsInfinity(past)
                        && atr > TickSize * 0.01 && !double.IsNaN(atr) && !double.IsInfinity(atr))
                    {
                        double rate = (now - past) / (lookback * atr);
                        double release = threshold * 0.60;
                        if (rate > threshold) state = 1;
                        else if (rate < -threshold) state = -1;
                        else if (Math.Abs(rate) >= release) state = previous;
                        // En la zona de pendiente casi horizontal: neutral, no se fuerza dirección.
                    }
                }
                slopeStateCache.Add(state);
            }
            return slopeStateCache[bar];
        }

        private WpfBrush SlopeBrushFor(int state)
        {
            return state > 0 ? (SlopeUpBrush ?? WpfBrushes.Green)
                : state < 0 ? (SlopeDownBrush ?? WpfBrushes.Red)
                : (SlopeFlatBrush ?? WpfBrushes.Gray);
        }

        private int TrendDirectionAt(int bar)
        {
            if (TrendFilterMode == PhaseTestTrendFilterMode.PendienteMA)
                return SlopeTrendAt(bar);
            int position = FilterTrendAt(bar);
            if (TrendFilterMode == PhaseTestTrendFilterMode.Combinado)
            {
                int slope = SlopeTrendAt(bar);
                return position != 0 && position == slope ? position : 0;
            }
            return position;
        }

        // Histeresis causal: la direccion solo cambia al cerrar fuera de la banda.
        // Recalculo historico lineal al editar holgura; incremental en nuevas barras.
        // No depende del viewport ni consulta ninguna barra futura.
        private int FilterTrendAt(int bar)
        {
            int tolerance = Math.Max(0, TrendToleranceTicks);
            if (bar < AveragePeriod * 2 || bar > lastClosedIndex || bar > LastLoaded)
                return 0;
            if (cachedToleranceTicks != tolerance)
            {
                trendStateCache.Clear();
                cachedToleranceTicks = tolerance;
            }
            double band = tolerance * TickSize;
            while (trendStateCache.Count <= bar)
            {
                int idx = trendStateCache.Count;
                int previous = idx > 0 ? trendStateCache[idx - 1] : 0;
                double ma = TrendAt(idx);
                double close = Bars.GetClose(idx);
                int direction = 0;
                if (!double.IsNaN(ma) && !double.IsInfinity(ma)
                    && !double.IsNaN(close) && !double.IsInfinity(close))
                {
                    double delta = close - ma;
                    if (delta > band) direction = 1;
                    else if (delta < -band) direction = -1;
                    else if (tolerance > 0) direction = previous;
                    // Holgura cero: coincidencia exacta = neutral, como antes.
                }
                trendStateCache.Add(direction);
            }
            return trendStateCache[bar];
        }

        // ATR estándar de Wilder: TR de cada barra y promedio recursivo con
        // n = min(periodo, barras disponibles), igual que el arranque de ATR de NT.
        // Se reconstruye bajo demanda si cambia el periodo, incluso sobre histórico.
        private double MarkerAtrAt(int bar)
        {
            if (bar < 0 || bar > lastClosedIndex || bar > LastLoaded) return double.NaN;
            int period = Math.Max(1, Math.Min(500, MarkerAtrPeriod));
            if (cachedMarkerAtrPeriod != period)
            {
                markerAtrCache.Clear();
                cachedMarkerAtrPeriod = period;
            }
            while (markerAtrCache.Count <= bar)
            {
                int i = markerAtrCache.Count;
                double high = Bars.GetHigh(i), low = Bars.GetLow(i);
                double tr = high - low;
                if (i > 0)
                {
                    double prevClose = Bars.GetClose(i - 1);
                    tr = Math.Max(tr, Math.Max(Math.Abs(high - prevClose), Math.Abs(low - prevClose)));
                }
                int n = Math.Min(i + 1, period);
                double atr = i == 0 ? tr : ((n - 1) * markerAtrCache[i - 1] + tr) / n;
                markerAtrCache.Add(atr);
            }
            return markerAtrCache[bar];
        }

        private static DXColor ToSignalColor(WpfBrush brush, DXColor fallback)
        {
            var solid = brush as System.Windows.Media.SolidColorBrush;
            if (solid == null) return fallback;
            var c = solid.Color;
            return new DXColor(c.R/255f, c.G/255f, c.B/255f, (float)(c.A/255.0*solid.Opacity));
        }

        // Excepcion visual y causal para la pareja A1/B2 (separadas UNA barra).
        // El cierre de A1 se conoce antes de que nazca B2: nunca se lee el cierre
        // de B2, ni se espera al siguiente miniciclo, ni se reclasifica la reticula.
        // Solo se aplica con ambas reticulas visibles y el filtro SOLO Favor.
        // El extremo EXTERIOR es el segundo limite de la zona porcentual (Hasta %).
        private bool A1CerroBajoBandaExterior(int a1Bar)
        {
            if (!ShowA || !ShowB || !ShowPercentBands || !ShowWithTrend || ShowAgainstTrend
                || a1Bar < Math.Max(0, AveragePeriod * 2) || a1Bar > lastClosedIndex
                || a1Bar > LastLoaded || PercentBaseRange <= 0.0
                || PercentTestLevel <= 0.0 || PercentZoneUpperLevel <= PercentTestLevel)
                return false;

            double ma = TrendAt(a1Bar);
            if (double.IsNaN(ma) || double.IsInfinity(ma) || ma == 0.0)
                return false;
            double close = Bars.GetClose(a1Bar);
            if (double.IsNaN(close) || double.IsInfinity(close))
                return false;
            double radius100 = Math.Abs(ma) * PercentBaseRange / 100.0;
            double limiteInferiorExterior = ma - radius100 * PercentZoneUpperLevel / 100.0;
            return close < limiteInferiorExterior;
        }

        // Regla simetrica: si A1 cierra estrictamente SOBRE el limite exterior
        // superior, la pareja elige B2 (en la barra siguiente) y atenúa A1.
        // La prueba usa SOLO OHLC cerrado en A1 y la media causal de A1.
        private bool A1CerroSobreBandaExterior(int a1Bar)
        {
            if (!ShowA || !ShowB || !ShowPercentBands || !ShowWithTrend || ShowAgainstTrend
                || a1Bar < Math.Max(0, AveragePeriod * 2) || a1Bar > lastClosedIndex
                || a1Bar > LastLoaded || PercentBaseRange <= 0.0
                || PercentTestLevel <= 0.0 || PercentZoneUpperLevel <= PercentTestLevel)
                return false;

            double ma = TrendAt(a1Bar);
            if (double.IsNaN(ma) || double.IsInfinity(ma) || ma == 0.0)
                return false;
            double close = Bars.GetClose(a1Bar);
            if (double.IsNaN(close) || double.IsInfinity(close))
                return false;
            double radius100 = Math.Abs(ma) * PercentBaseRange / 100.0;
            double limiteSuperiorExterior = ma + radius100 * PercentZoneUpperLevel / 100.0;
            return close > limiteSuperiorExterior;
        }

        // v1.0.26 · Nueva excepcion de la pareja A2/B1.
        // Si el cierre de A2 entra en la franja INFERIOR [Desde %, Hasta %],
        // A2 queda atenuada y B1 (que nace una barra despues) toma prioridad.
        // No usa la vela B1 ni consulta datos futuros: se decide al cierre A2.
        // Los limites se calculan con la MA causal del propio cierre A2.
        private bool A2CerroDentroZonaInferior(int a2Bar)
        {
            if (!ShowA || !ShowB || !ShowPercentBands || !ShowWithTrend || ShowAgainstTrend
                || a2Bar < Math.Max(0, AveragePeriod * 2) || a2Bar > lastClosedIndex
                || a2Bar > LastLoaded || PercentBaseRange <= 0.0
                || PercentTestLevel <= 0.0 || PercentZoneUpperLevel <= PercentTestLevel)
                return false;

            double ma = TrendAt(a2Bar);
            if (double.IsNaN(ma) || double.IsInfinity(ma) || ma == 0.0)
                return false;
            double close = Bars.GetClose(a2Bar);
            if (double.IsNaN(close) || double.IsInfinity(close))
                return false;

            double radius100 = Math.Abs(ma) * PercentBaseRange / 100.0;
            double limiteInferiorInterior = ma - radius100 * PercentTestLevel / 100.0;
            double limiteInferiorExterior = ma - radius100 * PercentZoneUpperLevel / 100.0;
            return close >= limiteInferiorExterior && close <= limiteInferiorInterior;
        }

        // v1.0.27 · Espejo causal de A2/B1: si A1 cierra DENTRO
        // de la franja SUPERIOR [Desde %, Hasta %], A1 queda gris
        // y su B2 de la barra posterior pasa a rojo. Solo usa el cierre
        // de A1 y la media conocida en esa misma barra; no lee B2.
        private bool A1CerroDentroZonaSuperior(int a1Bar)
        {
            if (!ShowA || !ShowB || !ShowPercentBands || !ShowWithTrend || ShowAgainstTrend
                || a1Bar < Math.Max(0, AveragePeriod * 2) || a1Bar > lastClosedIndex
                || a1Bar > LastLoaded || PercentBaseRange <= 0.0
                || PercentTestLevel <= 0.0 || PercentZoneUpperLevel <= PercentTestLevel)
                return false;

            double ma = TrendAt(a1Bar);
            if (double.IsNaN(ma) || double.IsInfinity(ma) || ma == 0.0)
                return false;
            double close = Bars.GetClose(a1Bar);
            if (double.IsNaN(close) || double.IsInfinity(close))
                return false;

            double radius100 = Math.Abs(ma) * PercentBaseRange / 100.0;
            double limiteSuperiorInterior = ma + radius100 * PercentTestLevel / 100.0;
            double limiteSuperiorExterior = ma + radius100 * PercentZoneUpperLevel / 100.0;
            return close >= limiteSuperiorInterior && close <= limiteSuperiorExterior;
        }

        // v1.0.28 · Pareja A2/B1 en la zona SUPERIOR: prevalece A2 bajista.
        // Se decide exclusivamente al CIERRE de A2. Su B1 posterior queda gris
        // sin consultar OHLC de esa barra futura.
        private bool A2CerroDentroZonaSuperior(int a2Bar)
        {
            if (!ShowA || !ShowB || !ShowPercentBands || !ShowWithTrend || ShowAgainstTrend
                || a2Bar < Math.Max(0, AveragePeriod * 2) || a2Bar > lastClosedIndex
                || a2Bar > LastLoaded || PercentBaseRange <= 0.0
                || PercentTestLevel <= 0.0 || PercentZoneUpperLevel <= PercentTestLevel)
                return false;

            double ma = TrendAt(a2Bar);
            if (double.IsNaN(ma) || double.IsInfinity(ma) || ma == 0.0)
                return false;
            double close = Bars.GetClose(a2Bar);
            if (double.IsNaN(close) || double.IsInfinity(close))
                return false;

            double radius100 = Math.Abs(ma) * PercentBaseRange / 100.0;
            double limiteSuperiorInterior = ma + radius100 * PercentTestLevel / 100.0;
            double limiteSuperiorExterior = ma + radius100 * PercentZoneUpperLevel / 100.0;
            return close >= limiteSuperiorInterior && close <= limiteSuperiorExterior;
        }

        // v1.0.28 · Pareja A1/B2 en la zona INFERIOR: prevalece A1 alcista.
        // Espejo de A2 en la franja superior. Se decide al cierre de A1.
        private bool A1CerroDentroZonaInferior(int a1Bar)
        {
            if (!ShowA || !ShowB || !ShowPercentBands || !ShowWithTrend || ShowAgainstTrend
                || a1Bar < Math.Max(0, AveragePeriod * 2) || a1Bar > lastClosedIndex
                || a1Bar > LastLoaded || PercentBaseRange <= 0.0
                || PercentTestLevel <= 0.0 || PercentZoneUpperLevel <= PercentTestLevel)
                return false;

            double ma = TrendAt(a1Bar);
            if (double.IsNaN(ma) || double.IsInfinity(ma) || ma == 0.0)
                return false;
            double close = Bars.GetClose(a1Bar);
            if (double.IsNaN(close) || double.IsInfinity(close))
                return false;

            double radius100 = Math.Abs(ma) * PercentBaseRange / 100.0;
            double limiteInferiorInterior = ma - radius100 * PercentTestLevel / 100.0;
            double limiteInferiorExterior = ma - radius100 * PercentZoneUpperLevel / 100.0;
            return close >= limiteInferiorExterior && close <= limiteInferiorInterior;
        }

        private bool AcceptSignal(int bar, int binary)
        {
            if (!ShowWithTrend && !ShowAgainstTrend) return false;
            if (bar > lastClosedIndex) return true; // proyeccion, filtro futuro desconocido
            if (ShowWithTrend && ShowAgainstTrend) return true;
            int direction = TrendDirectionAt(bar);
            if (direction == 0) return false;
            bool withTrend = binary == 1 ? direction > 0 : direction < 0;
            return withTrend ? ShowWithTrend : ShowAgainstTrend;
        }

        private int BinaryForOrder(int k, bool bPhase)
        {
            int initial = ((k % 2 == 0) ? BaseBinary : 3 - BaseBinary);
            return bPhase ? 3 - initial : initial;
        }

        // Traducir el selector nativo de NinjaTrader al estilo de SharpDX.
        private static SharpDX.Direct2D1.DashStyle ToDxDash(NinjaTrader.Gui.DashStyleHelper style)
        {
            switch (style.ToString())
            {
                case "Dash": return SharpDX.Direct2D1.DashStyle.Dash;
                case "Dot": return SharpDX.Direct2D1.DashStyle.Dot;
                case "DashDot": return SharpDX.Direct2D1.DashStyle.DashDot;
                case "DashDotDot": return SharpDX.Direct2D1.DashStyle.DashDotDot;
                default: return SharpDX.Direct2D1.DashStyle.Solid;
            }
        }

        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            if (IsInHitTest || templateLoading) return; // no leer datos parcialmente restaurados
            base.OnRender(chartControl, chartScale);
            if (ChartBars == null || ChartPanel == null || LastLoaded < 10 || RenderTarget == null) return;
            EnsureAnchors();
            if (!anchorsInitialized)
            {
                if (toolbarLabel != null && toolbarLabel.Text != anchorStatus) toolbarLabel.Text = anchorStatus;
                return;
            }
            if (nativeAnchor == null) QueueNativeAnchor();
            else ReadNativeAnchor();
            int a, b; double ya, yb;
            lock (anchorGate) { a=anchorIndexA; b=anchorIndexB; ya=anchorPriceA; yb=anchorPriceB; }
            int step = Math.Max(2, b-a);
            if (toolbarLabel != null)
            {
                string info = "Intervalo fijo · " + step.ToString(CultureInfo.InvariantCulture)
                    + " barras · B = A+1 · " + anchorStatus;
                if (toolbarLabel.Text != info) toolbarLabel.Text = info;
            }
            int visibleStart = Math.Max(0, ChartBars.FromIndex - step);
            float yTop = (float)ChartPanel.Y, yBottom = (float)(ChartPanel.Y + ChartPanel.H);
            float xLeft = (float)ChartPanel.X, xRight = (float)(ChartPanel.X + ChartPanel.W);
            if (yBottom <= yTop) return;
            DrawAnchorCycleBand(chartControl, a, b, xLeft, xRight, yTop, yBottom);
            DrawPercentBands(chartControl, chartScale, xLeft, xRight, yTop, yBottom);
            using (DXBrush green = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, ToSignalColor(SignalBuyBrush, new DXColor(0.10f, 0.82f, 0.23f, 1f))))
            using (DXBrush red = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, ToSignalColor(SignalSellBrush, new DXColor(0.98f, 0.18f, 0.22f, 1f))))
            using (DXBrush muted = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, ToSignalColor(SignalMutedBrush, new DXColor(0.55f, 0.55f, 0.55f, 0.55f))))
            using (DXBrush mirror = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, new DXColor(0.78f, 0.78f, 0.78f, 0.8f)))
            using (StrokeStyle verticalStyle = new StrokeStyle(RenderTarget.Factory, new StrokeStyleProperties { DashStyle = ToDxDash(SignalVerticalStyle) }))
            using (StrokeStyle horizontalStyle = new StrokeStyle(RenderTarget.Factory, new StrokeStyleProperties { DashStyle = ToDxDash(SignalHorizontalStyle) }))
            using (StrokeStyle dotted = new StrokeStyle(RenderTarget.Factory, new StrokeStyleProperties { DashStyle = SharpDX.Direct2D1.DashStyle.Dot }))
            using (TextFormat fmt = new TextFormat(Core.Globals.DirectWriteFactory, "Segoe UI", (float)SignalLabelFontSize))
            {
                if (ShowA) DrawSequence(chartControl, chartScale, a, step, false, visibleStart, yTop, yBottom, green, red, muted, verticalStyle, horizontalStyle, fmt);
                if (ShowB)
                {
                    DrawSequence(chartControl, chartScale, a+1, step, true, visibleStart, yTop, yBottom, green, red, muted, verticalStyle, horizontalStyle, fmt);
                    // B no es otra distancia: ambos extremos son A+1 exactamente.
                    float x1=GetBarX(chartControl,a+1), x2=GetBarX(chartControl,b+1);
                    float y1=(float)chartScale.GetYByValue(ya), y2=(float)chartScale.GetYByValue(yb);
                    if (!float.IsNaN(x1) && !float.IsNaN(x2) && x2 >= xLeft && x1 <= xRight)
                    {
                        RenderTarget.DrawLine(new Vector2(x1,y1),new Vector2(x2,y2),mirror,1f,dotted);
                        if (x1>=xLeft && x1<=xRight && y1>=yTop && y1<=yBottom)
                            RenderTarget.DrawEllipse(new Ellipse(new Vector2(x1,y1),5,5),mirror,1.5f);
                        if (x2>=xLeft && x2<=xRight && y2>=yTop && y2<=yBottom)
                            RenderTarget.DrawEllipse(new Ellipse(new Vector2(x2,y2),5,5),mirror,1.5f);
                    }
                }
            }
        }

        // Solo la pareja editable A0/A1: ni el resto de los ciclos ni la copia B.
        // Las coordenadas se obtienen de la misma geometría que las líneas de señal.
        private void DrawAnchorCycleBand(ChartControl cc, int a, int b,
            float xLeft, float xRight, float yTop, float yBottom)
        {
            if (!HighlightAnchorCycle || AnchorCycleOpacity <= 0 || a < 0 || b <= a
                || xRight <= xLeft) return;
            float x1 = GetBarX(cc, a), x2 = GetBarX(cc, b);
            if (float.IsNaN(x1) || float.IsNaN(x2) || float.IsInfinity(x1) || float.IsInfinity(x2)) return;
            float left = Math.Max(xLeft, Math.Min(x1, x2));
            float right = Math.Min(xRight, Math.Max(x1, x2));
            if (right <= left) return;
            DXColor color = ToSignalColor(AnchorCycleBrush, new DXColor(234f/255f,179f/255f,8f/255f,1f));
            color.Alpha *= Math.Max(0, Math.Min(100, AnchorCycleOpacity)) / 100f;
            using (DXBrush fill = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, color))
                RenderTarget.FillRectangle(new SharpDX.RectangleF(left, yTop, right-left, yBottom-yTop), fill);
        }

        // Zonas simetricas, causales y sin repintado: para cada cierre se calculan
        // dos limites a cada lado de la MA. El relleno se compone de segmentos
        // trapezoidales continuos, recortados al viewport, sin desplazar señales.
        // R100 = abs(MA) * PercentBaseRange / 100; Z = MA +/- R100 * umbral / 100.
        private void DrawPercentBands(ChartControl cc, ChartScale cs,
            float xLeft, float xRight, float yTop, float yBottom)
        {
            if (!ShowPercentBands || activeAverage == null || lastClosedIndex < AveragePeriod * 2
                || PercentBaseRange <= 0 || PercentTestLevel < 0.1
                || PercentZoneUpperLevel <= PercentTestLevel || xRight <= xLeft) return;
            int first = Math.Max(AveragePeriod * 2, ChartBars.FromIndex - 2);
            int end = Math.Min(lastClosedIndex, Math.Min(LastLoaded, ChartBars.ToIndex + 2));
            if (first > end) return;
            DXColor edgeColor = ToSignalColor(PercentBandBrush, new DXColor(0.80f, 0.60f, 1f, 1f));
            DXColor fillColor = ToSignalColor(PercentZoneBrush, new DXColor(0.70f, 0.51f, 0.90f, 1f));
            fillColor.Alpha *= Math.Max(0, Math.Min(100, PercentZoneOpacity)) / 100f;
            float width = Math.Max(1f, Math.Min(8f, PercentBandWidth));
            using (DXBrush edge = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, edgeColor))
            using (DXBrush fill = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, fillColor))
            using (StrokeStyle lineStyle = new StrokeStyle(RenderTarget.Factory,
                new StrokeStyleProperties { DashStyle = ToDxDash(PercentBandStyle) }))
            using (SharpDX.Direct2D1.PathGeometry zoneGeometry = new SharpDX.Direct2D1.PathGeometry(RenderTarget.Factory))
            {
                // Una unica geometria para ambas zonas: evita un draw call por vela.
                using (GeometrySink sink = zoneGeometry.Open())
                {
                    bool previousValid = false;
                    float px = 0, pUi = 0, pUo = 0, pDi = 0, pDo = 0;
                    // Guardar los cuatro limites para dibujarlos tras el relleno.
                    var samples = new List<float[]>();
                    for (int i = first; i <= end; i++)
                    {
                        double ma = TrendAt(i);
                        float x = GetBarX(cc, i);
                        if (double.IsNaN(ma) || double.IsInfinity(ma) || ma == 0.0
                            || float.IsNaN(x) || float.IsInfinity(x)) { previousValid = false; samples.Add(null); continue; }
                        double radius = Math.Abs(ma) * PercentBaseRange / 100.0;
                        float ui = (float)cs.GetYByValue(ma + radius * PercentTestLevel / 100.0);
                        float uo = (float)cs.GetYByValue(ma + radius * PercentZoneUpperLevel / 100.0);
                        float di = (float)cs.GetYByValue(ma - radius * PercentTestLevel / 100.0);
                        float dO = (float)cs.GetYByValue(ma - radius * PercentZoneUpperLevel / 100.0);
                        if (float.IsNaN(ui) || float.IsNaN(uo) || float.IsNaN(di) || float.IsNaN(dO)
                            || float.IsInfinity(ui) || float.IsInfinity(uo) || float.IsInfinity(di) || float.IsInfinity(dO))
                        { previousValid = false; samples.Add(null); continue; }
                        samples.Add(new float[] { x, ui, uo, di, dO });
                        if (previousValid && x > px)
                        {
                            sink.BeginFigure(new Vector2(px, pUi), FigureBegin.Filled);
                            sink.AddLine(new Vector2(px, pUo));
                            sink.AddLine(new Vector2(x, uo));
                            sink.AddLine(new Vector2(x, ui));
                            sink.EndFigure(FigureEnd.Closed);
                            sink.BeginFigure(new Vector2(px, pDi), FigureBegin.Filled);
                            sink.AddLine(new Vector2(px, pDo));
                            sink.AddLine(new Vector2(x, dO));
                            sink.AddLine(new Vector2(x, di));
                            sink.EndFigure(FigureEnd.Closed);
                        }
                        px = x; pUi = ui; pUo = uo; pDi = di; pDo = dO;
                        previousValid = true;
                    }
                    sink.Close();
                    RenderTarget.PushAxisAlignedClip(new SharpDX.RectangleF(xLeft, yTop, xRight-xLeft, yBottom-yTop),
                        SharpDX.Direct2D1.AntialiasMode.PerPrimitive);
                    try
                    {
                        if (fillColor.Alpha > 0.001f) RenderTarget.FillGeometry(zoneGeometry, fill);
                        float[] last = null;
                        foreach (float[] current in samples)
                        {
                            if (current != null && last != null && current[0] > last[0])
                                for (int k = 1; k <= 4; k++)
                                    RenderTarget.DrawLine(new Vector2(last[0], last[k]),
                                        new Vector2(current[0], current[k]), edge, width, lineStyle);
                            last = current;
                        }
                    }
                    finally { RenderTarget.PopAxisAlignedClip(); }
                }
            }
        }

        private void DrawSequence(ChartControl cc, ChartScale cs, int start, int step, bool bPhase,
            int visibleStart, float yTop, float yBottom, DXBrush green, DXBrush red, DXBrush muted, StrokeStyle verticalStyle, StrokeStyle horizontalStyle, TextFormat fmt)
        {
            // La ventana visible afecta solo al recorte, nunca a origen/periodo/fase.
            // FutureSignals se cuenta desde la ultima B0 cerrada, no desde el ancla.
            int closed = Math.Min(lastClosedIndex, LastLoaded);
            if (closed < 0) return;
            int first = (int)Math.Floor((visibleStart-start)/(double)step);
            int lastHistorical = (int)Math.Floor((closed-start)/(double)step);
            int lastAllowed = lastHistorical+FutureSignals;
            // Maximo de historicas por ventana: al hacer scroll se muestran las
            // correspondientes a esa zona; los indices no dependen de ella.
            int lastVisible = (int)Math.Ceiling((ChartBars.ToIndex-start)/(double)step)+FutureSignals+2;
            int end = Math.Min(lastAllowed,lastVisible);
            int renderedPast = 0;
            for (int k=first;k<=end;k++)
            {
                long candidate = (long)start+(long)k*step;
                if (candidate<0 || candidate>int.MaxValue) continue;
                int idx = (int)candidate;
                if (idx<visibleStart) continue;
                // No recorrer del viewport historico hasta hoy: corte X inmediato.
                float x=GetBarX(cc,idx);
                if (float.IsNaN(x) || x > ChartPanel.X+ChartPanel.W+15) break;
                if (idx<=closed && x>=ChartPanel.X && ++renderedPast>HistorySignals) break;
                DrawSignal(cc,cs,idx,idx+step,BinaryForOrder(k,bPhase),bPhase,yTop,yBottom,green,red,muted,verticalStyle,horizontalStyle,fmt);
            }
        }

        private void DrawSignal(ChartControl cc, ChartScale cs, int idx, int nextIdx, int binary, bool isB,
            float yTop, float yBottom, DXBrush green, DXBrush red, DXBrush muted, StrokeStyle verticalStyle, StrokeStyle horizontalStyle, TextFormat fmt)
        {
            // Ambos filtros apagados conservan su significado: ocultar todas las señales.
            if (!ShowWithTrend && !ShowAgainstTrend) return;
            bool accepted = AcceptSignal(idx,binary);
            // Excepciones de prioridad visual: siempre se resuelven con el
            // CIERRE de la vela A, sin leer el cierre de la siguiente B.
            // Priorizacion causal por pareja A(t) / B(t+1), sin mirar B(t+1):
            // A1 inferior (zona o debajo de exterior) -> A1 verde, B2 gris.
            // A1 superior (zona o encima de exterior) -> A1 gris, B2 rojo.
            // A2 inferior (zona) -> A2 gris, B1 verde.
            // A2 superior (zona) -> A2 rojo, B1 gris (v1.0.28).
            if (!isB && binary == 1)
            {
                if (A1CerroBajoBandaExterior(idx) || A1CerroDentroZonaInferior(idx)) accepted = true;
                else if (A1CerroSobreBandaExterior(idx) || A1CerroDentroZonaSuperior(idx)) accepted = false;
            }
            else if (isB && binary == 2)
            {
                if (A1CerroBajoBandaExterior(idx - 1) || A1CerroDentroZonaInferior(idx - 1)) accepted = false;
                else if (A1CerroSobreBandaExterior(idx - 1) || A1CerroDentroZonaSuperior(idx - 1)) accepted = true;
            }
            else if (!isB && binary == 2)
            {
                if (A2CerroDentroZonaInferior(idx)) accepted = false;
                else if (A2CerroDentroZonaSuperior(idx)) accepted = true;
            }
            else if (isB && binary == 1)
            {
                if (A2CerroDentroZonaInferior(idx - 1)) accepted = true;
                else if (A2CerroDentroZonaSuperior(idx - 1)) accepted = false;
            }
            float x=GetBarX(cc,idx);
            if (float.IsNaN(x) || float.IsInfinity(x) || x<ChartPanel.X-10 || x>ChartPanel.X+ChartPanel.W+15) return;
            bool future = idx>lastClosedIndex;
            // El gris es exclusivamente visual: no reclasifica ni fuerza una señal.
            DXBrush color = accepted ? (binary==1 ? green : red) : muted;
            RenderTarget.DrawLine(new Vector2(x,yTop),new Vector2(x,yBottom),color,(float)(accepted ? SignalVerticalWidth : MutedVerticalWidth),verticalStyle);
            string label = (isB?"B":"A")+binary.ToString(CultureInfo.InvariantCulture);
            if (future)
            {
                // Solo fecha/slot y binaria. El precio futuro y su filtro se desconocen.
                float fs = (float)SignalLabelFontSize;
                RenderTarget.DrawText(label+"?",fmt,new SharpDX.RectangleF(x+3,yTop+18,Math.Max(45f,fs*3.5f),Math.Max(18f,fs*1.6f)),color);
                return;
            }
            // Posicion visual solicitada: 1 verde bajo el minimo; 2 rojo sobre el maximo.
            // A y B comparten exactamente el mismo estilo y offset.
            double offset = MarkerOffsetTicks * TickSize;
            if (UseAtrMarkerOffset)
            {
                double atrValue = MarkerAtrAt(idx);
                if (!double.IsNaN(atrValue) && !double.IsInfinity(atrValue) && atrValue >= 0)
                    offset = MarkerOffsetAtrMultiple * atrValue;
            }
            offset = Math.Ceiling(Math.Max(0.0, offset) / TickSize - 1e-9) * TickSize;
            offset = Math.Max(0.0, offset);
            double price=binary==1 ? Bars.GetLow(idx)-offset : Bars.GetHigh(idx)+offset;
            float y=(float)cs.GetYByValue(price);
            // No pegar el marcador al borde si su precio esta fuera de escala.
            float radius = (accepted ? SignalDotSize : MutedDotSize) / 2f;
            if (y<yTop+radius || y>yBottom-radius) return;
            Ellipse mark=new Ellipse(new Vector2(x,y),radius,radius);
            RenderTarget.FillEllipse(mark,color);
            float endX=GetBarX(cc,nextIdx);
            if (!float.IsNaN(endX))
            {
                endX=Math.Min((float)(ChartPanel.X+ChartPanel.W),endX-2);
                float lineStart = x + radius + 0.5f;
                if (endX>lineStart) RenderTarget.DrawLine(new Vector2(lineStart,y),new Vector2(endX,y),color,(float)(accepted ? SignalHorizontalWidth : MutedHorizontalWidth),horizontalStyle);
            }
            float fontSize = (float)SignalLabelFontSize;
            float labelHeight = Math.Max(18f, fontSize * 1.6f);
            float textY=binary==1 ? y+Math.Max(3f,radius-2.5f) : y-radius-labelHeight+3.5f;
            RenderTarget.DrawText(label,fmt,new SharpDX.RectangleF(x+Math.Max(5f,radius),textY,Math.Max(36f,fontSize*3f),labelHeight),color);
        }
    }
}
